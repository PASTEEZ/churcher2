<?php $__env->startSection('title'); ?> 
<?php echo app('translator')->get('student.student_edit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backEnd/')); ?>/css/croppie.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>

<section class="sms-breadcrumb up_breadcrumb mb-40 white-box">
    <div class="container-fluid">
        <div class="row justify-content-between">
            <h1><?php echo app('translator')->get('student.student_edit'); ?></h1>
            <div class="bc-pages">
                <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('common.dashboard'); ?></a>
                <a href="<?php echo e(route('student_list')); ?>"><?php echo app('translator')->get('common.student_list'); ?></a>
                <a href="#"><?php echo app('translator')->get('student.student_edit'); ?></a>
            </div>
        </div>
    </div>
</section>

<section class="admin-visitor-area up_st_admin_visitor">
    <div class="container-fluid p-0">
        <div class="row mb-30">
            <div class="col-lg-6">
                <div class="main-title">
                    <h3><?php echo app('translator')->get('student.student_edit'); ?></h3>
                </div>
            </div>
        </div>
        <?php echo e(Form::open(['class' => 'form-horizontal', 'files' => true, 'route' => 'student_update',
                        'method' => 'POST', 'enctype' => 'multipart/form-data', 'id' => 'student_form'])); ?>

        <div class="row">
            <div class="col-lg-12">
                <?php if(session()->has('message-success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('message-success')); ?>

                  </div>
                <?php elseif(session()->has('message-danger')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session()->get('message-danger')); ?>

                  </div>
                <?php endif; ?>
                <div class="white-box">
                    <div class="">
                        <div class="row mb-4">
                            <div class="col-lg-12 text-center">

                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($error == "The email address has already been taken."): ?>
                                        <div class="error text-danger ">
                                            <?php echo e('The email address has already been taken, You can find out in student list or disabled student list'); ?>

                                        </div>
                                    <?php endif; ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                     <div class="error text-danger "><?php echo e('Something went wrong, please try again'); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-12">
                                <div class="main-title">
                                    <h4 class="stu-sub-head"><?php echo app('translator')->get('student.personal_info'); ?></h4>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="url" id="url" value="<?php echo e(URL::to('/')); ?>"> 
                        <input type="hidden" name="id" id="id" value="<?php echo e($student->id); ?>">

                      








                        <div class="row mb-40 mt-30">
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('session') ? ' is-invalid' : ''); ?>" name="session" id="academic_year">
                                        <option data-display="<?php echo app('translator')->get('common.academic_year'); ?> <?php if(is_required('session')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('common.academic_year'); ?> <?php if(is_required('session')==true): ?> * <?php endif; ?></option>
                                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($session->id); ?>" <?php echo e(old('session', getAcademicId()) == $session->id? 'selected': ''); ?>><?php echo e($session->year); ?>[<?php echo e($session->title); ?>]</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('session')): ?>
                                    <span class="invalid-feedback invalid-select" role="alert">
                                        <strong><?php echo e($errors->first('session')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php
                                $classes = DB::table('sm_classes')->where('academic_id', '=', old('session', getAcademicId()))
                                ->get();
                            ?>
                        
                           
                           
                            <?php if(!empty(old('class'))): ?>
                            <?php
                                $old_sections = DB::table('sm_class_sections')->where('class_id', '=', old('class'))
                                ->join('sm_sections','sm_class_sections.section_id','=','sm_sections.id')
                                ->get();
                            ?>
                     
                            <?php else: ?>

                         
                            <?php endif; ?>

                            <?php if(is_show('admission_number')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect">
                                        <input class="primary-input form-control<?php echo e($errors->has('admission_number') ? ' is-invalid' : ''); ?>" type="text" name="admission_number" value="<?php echo e($student->admission_no); ?>" onkeyup="GetAdminUpdate(this.value,<?php echo e($student->id); ?>)">
                             
                     
                                   <label><?php echo app('translator')->get('student.admission_number'); ?> <?php if(is_required('admission_number')==true): ?> * <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <span class="invalid-feedback" id="Admission_Number" role="alert">
                                    </span>
                                    <?php if($errors->has('admission_number')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('admission_number')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(is_show('admission_date')): ?>
                            <div class="col-lg-2">
                                <div class="no-gutters input-right-icon">
                                    <div class="col">
                                        <div class="input-effect sm2_mb_20 md_mb_20">
                                            <input class="primary-input date" id="endDate" type="text" name="admission_date" value="<?php echo e($student->admission_date != ""? date('m/d/Y', strtotime($student->admission_date)): date('m/d/Y')); ?>" autocomplete="off">
                                            <label><?php echo app('translator')->get('student.admission_date'); ?></label>
                                            <span class="focus-border">  <?php if(is_required('admission_date')==true): ?> <span> *</span> <?php endif; ?></span>
                                            <?php if($errors->has('admission_date')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('admission_date')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <button class="" type="button">
                                            <i class="ti-calendar" id="admission-date-icon"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?> 

                        </div>
                        
                  
                        <div class="col-lg-1">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('student_category_id') ? ' is-invalid' : ''); ?>" name="student_category_id">
                                        <option data-display="<?php echo app('translator')->get('student.category'); ?> <?php if(is_required('student_category_id')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('student.category'); ?> <?php if(is_required('student_category_id')==true): ?> <span> *</span> <?php endif; ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($student->student_category_id)): ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e($student->student_category_id == $category->id? 'selected': ''); ?>><?php echo e($category->category_name); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                <span class="focus-border"></span>
                                <?php if($errors->has('student_category_id')): ?>
                                <span class="invalid-feedback invalid-select" role="alert">
                                    <strong><?php echo e($errors->first('student_category_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            </div>
                        </div>
                      
                        <div class="row mb-40">
                            <?php if(is_show('first_name')): ?>
                                <div class="col-lg-3">
                                    <div class="input-effect sm2_mb_20 md_mb_20">
                                        <input class="primary-input form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" type="text" name="first_name"  value="<?php echo e($student->first_name); ?>">
                                        <label><?php echo app('translator')->get('student.first_name'); ?>  <?php if(is_required('first_name')==true): ?> <span> *</span> <?php endif; ?> </label>
                                        <span class="focus-border"></span>
                                        <?php if($errors->has('first_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('first_name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                          
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input form-control<?php echo e($errors->has('middle_name') ? ' is-invalid' : ''); ?>" type="text" name="middle_name"  value="<?php echo e($student->middle_name); ?>">
                                    <label><?php echo app('translator')->get('student.middle_name'); ?>  <?php if(is_required('middle_name')==true): ?> <span> *</span> <?php endif; ?> </label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('middle_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('middle_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                 
                            <?php if(is_show('last_name')): ?>
                                <div class="col-lg-3">
                                    <div class="input-effect sm2_mb_20 md_mb_20">
                                        <input class="primary-input form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" type="text" name="last_name"  value="<?php echo e($student->last_name); ?>">
                                        <label><?php echo app('translator')->get('student.last_name'); ?>  <?php if(is_required('last_name')==true): ?> <span> *</span> <?php endif; ?></label>
                                        <span class="focus-border"></span>
                                        <?php if($errors->has('last_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('last_name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                           
                            <?php if(is_show('date_of_birth')): ?>
                            <div class="col-lg-3">
                                <div class="no-gutters input-right-icon">
                                    <div class="col">
                                        <div class="input-effect sm2_mb_20 md_mb_20">
                                            <input class="primary-input date form-control<?php echo e($errors->has('date_of_birth') ? ' is-invalid' : ''); ?>" id="startDate" type="text" name="date_of_birth" value="<?php echo e(date('m/d/Y', strtotime($student->date_of_birth))); ?>" autocomplete="off">
                                          
                                                <label><?php echo app('translator')->get('common.date_of_birth'); ?>  <?php if(is_required('date_of_birth')==true): ?> <span> *</span> <?php endif; ?></label>
                                               
                                                <span class="focus-border"></span>
                                            <?php if($errors->has('date_of_birth')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('date_of_birth')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <button class="" type="button">
                                            <i class="ti-calendar" id="start-date-icon"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?> 
                        </div>
                        <div class="row mb-40">
                          
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input  class="primary-input phone_number form-control<?php echo e($errors->has('aka') ? ' is-invalid' : ''); ?>" type="text" name="aka" id="aka" value="<?php echo e($student->aka); ?>">
                                    
                                    <label><?php echo app('translator')->get('student.aka'); ?>  <?php if(is_required('aka')==true): ?> <span> *</span> <?php endif; ?></label>
                                  
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('aka')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('aka')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if(is_show('religion')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('religion') ? ' is-invalid' : ''); ?>" name="religion">
                                        <option data-display="<?php echo app('translator')->get('student.religion'); ?> <?php if(is_required('religion')==true): ?> <?php endif; ?>" value=""><?php echo app('translator')->get('student.religion'); ?> <?php if(is_required('religion')==true): ?> <span> *</span> <?php endif; ?></option>
                                        <?php $__currentLoopData = $blood_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($student->bloodgroup_id)): ?>
                                            <option value="<?php echo e($blood_group->id); ?>" <?php echo e($blood_group->id == $student->bloodgroup_id? 'selected': ''); ?>><?php echo e($blood_group->base_setup_name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($blood_group->id); ?>"><?php echo e($blood_group->base_setup_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('religion')): ?>
                                    <span class="invalid-feedback invalid-select" role="alert">
                                        <strong><?php echo e($errors->first('religion')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                           
                            <?php if(is_show('caste')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input" type="text" name="caste" value="<?php echo e($student->caste); ?>">
                                    <label><?php echo app('translator')->get('student.caste'); ?> <?php if(is_required('caste')==true): ?> <span> *</span> <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('caste')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('caste')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 

                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input nationality form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" id="nationality" type="text" name="nationality" value="<?php echo e(old('nationality')); ?>">
                                    <label><?php echo app('translator')->get('common.nationality'); ?>  <?php if(is_required('nationality')==true): ?> <span> *</span> <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('nationality')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nationality')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if(is_show('blood_group')): ?>
                            <div class="col-lg-2">
                               <div class="input-effect sm2_mb_20 md_mb_20">
                                <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('blood_group') ? ' is-invalid' : ''); ?>" name="blood_group">
                                    <option data-display="<?php echo app('translator')->get('student.blood_group'); ?> <?php if(is_required('blood_group')==true): ?>  * <?php endif; ?>" value=""><?php echo app('translator')->get('student.blood_group'); ?> <?php if(is_required('blood_group')==true): ?> <span> *</span> <?php endif; ?></option>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($student->bloodgroup_id)): ?>
                                        <option value="<?php echo e($blood_group->id); ?>" <?php echo e($blood_group->id == $student->bloodgroup_id? 'selected': ''); ?>><?php echo e($blood_group->base_setup_name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($blood_group->id); ?>"><?php echo e($blood_group->base_setup_name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                   <span class="focus-border"></span>
                                   <?php if($errors->has('blood_group')): ?>
                                   <span class="invalid-feedback invalid-select" role="alert">
                                       <strong><?php echo e($errors->first('blood_group')); ?></strong>
                                   </span>
                                   <?php endif; ?>
                               </div>
                           </div>
                           <?php endif; ?> 
                           
                          
                         
                           
                           
                        </div>
                        <div class="ro mb-40 d-none" id="exitStudent">
                            <div class="col-lg-12">
                                <input type="checkbox" id="edit_info" value="yes" class="common-checkbox" name="edit_info">
                                <label for="edit_info" class="text-danger"><?php echo app('translator')->get('student.student_already_exit_this_phone_number/email_are_you_to_edit_student_parent_info'); ?></label>
                            </div>
                        </div>
                        <div class="row mb-40">

                                     <?php if(is_show('dormitory_name')): ?>
                                <div class="col-lg-2">
                                    <div class="input-effect sm2_mb_20 md_mb_20">
                                        <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('dormitory_name') ? ' is-invalid' : ''); ?>" name="dormitory_name" id="SelectDormitory">
                                            <option data-display="<?php echo app('translator')->get('dormitory.dormitory_name'); ?>" <?php if(is_required('dormitory_name')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('dormitory.dormitory_name'); ?> <?php if(is_required('dormitory_name')==true): ?> <span> *</span> <?php endif; ?></option >
                                            <?php $__currentLoopData = $dormitory_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dormitory_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dormitory_list->id); ?>" <?php echo e(old('dormitory_name') == $dormitory_list->id? 'selected': ''); ?>><?php echo e($dormitory_list->dormitory_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="focus-border"></span>
                                        <?php if($errors->has('dormitory_name')): ?>
                                        <span class="invalid-feedback invalid-select" role="alert">
                                            <strong><?php echo e($errors->first('dormitory_name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?> 
                                <?php if(is_show('room_number')): ?>
                                <div class="col-lg-2">
                                    <div class="input-effect sm2_mb_20 md_mb_20" id="roomNumberDiv">
                                        <select class="niceSelect w-100 bb form-control" name="room_number" id="selectRoomNumber">
                                            <option data-display="<?php echo app('translator')->get('academics.room_number'); ?> <?php if(('room_number')==true): ?> <span> *</span> <?php endif; ?>" value=""><?php echo app('translator')->get('academics.room_number'); ?> <?php if(('room_number')==true): ?> <span> *</span> <?php endif; ?></option>
                                        </select>
                                        <div class="pull-right loader loader_style" id="select_dormitory_loader">
                                            <img class="loader_img_style" src="<?php echo e(asset('public/backEnd/img/demo_wait.gif')); ?>" alt="loader">
                                        </div>
                                        <span class="focus-border"></span>
                                      
                                    </div>
                                </div>
                                <?php endif; ?> 
                         
                           
                          
                           
                             <?php if(is_show('gender')): ?>
                             <div class="col-lg-2">
                                 <div class="input-effect sm2_mb_20 md_mb_20">
                                     <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>" name="gender">                          
                                         <option data-display="<?php echo app('translator')->get('common.gender'); ?> <?php if(is_required('gender')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('common.gender'); ?> <?php if(is_required('gender')==true): ?> <span>*</span> <?php endif; ?> </option>
                                         <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($gender->id); ?>" <?php echo e(old('gender') == $gender->id? 'selected': ''); ?>><?php echo e($gender->base_setup_name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
                                     </select>
                                     <span class="focus-border"></span>
                                     <?php if($errors->has('gender')): ?>
                                     <span class="invalid-feedback invalid-select" role="alert">
                                         <strong><?php echo e($errors->first('gender')); ?></strong>
                                     </span>
                                     <?php endif; ?>
                                 </div>
                             </div>
                             <?php endif; ?> 
                       






                            <?php if(is_show('student_group_id')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <div class="input-effect sm2_mb_20 md_mb_20">
                                    <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('student_group_id') ? ' is-invalid' : ''); ?>" name="student_group_id">
                                        <option data-display="<?php echo app('translator')->get('student.group'); ?>  <?php if(is_required('student_group_id')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('student.group'); ?>  <?php if(is_required('student_group_id')==true): ?> <span> *</span> <?php endif; ?></option>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($group->id); ?>" <?php echo e(old('student_group_id') == $group->id? 'selected': ''); ?>><?php echo e($group->group); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('student_group_id')): ?>
                                    <span class="invalid-feedback invalid-select" role="alert">
                                        <strong><?php echo e($errors->first('student_group_id')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <?php if(is_show('height')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input" type="text" name="height" value="<?php echo e($student->height); ?>">
                                    <label><?php echo app('translator')->get('student.height_in'); ?>  <?php if(is_required('height')==true): ?> <span> *</span> <?php endif; ?> </label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('height')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('height')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <?php if(is_show('weight')): ?>
                            <div class="col-lg-2">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <select class="niceSelect w-100 bb" name="weight" value="<?php echo e($student->weight); ?>">
                                    <option data-display="Select Qualification" >Select Highest Edu. Qualification</option>
                                        <option value="BECE">BECE</option>
                                        <option value="WASSCE">WASSCE/SSCE</option>
                                        <option value="DIPLOMA">DIPLOMA</option>
                                        <option value="DEGREE">DEGREE</option>
                                        <option value="MASTERS">MASTERS</option>
                                        <option value="PHD">PHD</option>
                                        <option value="NO QUALIFICATION">NO QUALIFICATION</option>
                                    </select>

                                  <span class="focus-border"></span>
                                    <?php if($errors->has('weight')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('weight')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                            <?php endif; ?> 
                        </div>

                        
                    <div class="row mb-30 mt-30">
                        <?php if(is_show('national_id_number')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input class="primary-input form-control<?php echo e($errors->has('national_id_number') ? ' is-invalid' : ''); ?>" type="text" name="national_id_number" value="<?php echo e($student->national_id_no); ?>">
                                <label><?php echo app('translator')->get('common.national_id_number'); ?> <?php if(is_required('national_id_number')==true): ?> <span> *</span> <?php endif; ?> </label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('national_id_number')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('national_id_number')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?> 
                        
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                   <select class="niceSelect w-100 bb" name="local_id_number" value="<?php echo e($student->child_name1); ?>">
                           
                                    <option data-display="Select Communicant status" >Are you a Communicant?</option>
                                    <option value="YES">YES</option>
                                    <option value="NO">NO</option>
                                
                                </select>
                                   <span class="focus-border"></span>
                               
                            </div>
                        </div>
                     
                        <?php if(is_show('bank_account_number')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                
                                   <select class="niceSelect w-100 bb" name="bank_account_number">
                           
                                <option data-display="Select Day Born" >Select Day Born</option>
                                <option value="SUNDAY">SUNDAY</option>
                                <option value="MONDAY">MONDAY</option>
                                <option value="TUESDAY">TUESDAY</option>
                                <option value="WEDNESDAY">WEDNESDAY</option>
                                <option value="THURSDAY">THURSDAY</option>
                                <option value="FRIDAY">FRIDAY</option>
                                <option value="SATURDAY">SATURDAY</option>
                            </select>
                            <label><?php echo app('translator')->get('accounts.bank_account_number'); ?><?php if(is_required('bank_account_number')==true): ?> <span> *</span> <?php endif; ?> </label>
                           
                                <span class="focus-border"></span>
                                 
                            </div>
                        </div>
                        <?php endif; ?> 
                        <?php if(is_show('bank_name')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input class="primary-input" type="text" name="bank_name" value="<?php echo e(old('bank_name')); ?>">
                                <label><?php echo app('translator')->get('student.bank_name'); ?> <?php if(is_required('bank_name')==true): ?> <span> *</span> <?php endif; ?> </label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('bank_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('bank_name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?> 
                    </div>
                        <?php if(moduleStatusCheck('Lead')==true): ?>
                        <div class="row mb-40">
                            <?php if(is_show('source_id')): ?>                           
                            <div class="col-lg-4 ">
                                <div class="input-effect">
                                        <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('route') ? ' is-invalid' : ''); ?>" name="source_id" id="source_id">
                                            <option data-display="<?php echo app('translator')->get('lead::lead.source'); ?> <?php if(is_required('source_id')==true): ?> * <?php endif; ?>" value=""><?php echo app('translator')->get('lead::lead.source'); ?> <?php if(is_required('source_id')==true): ?> <span> *</span> <?php endif; ?></option>
                                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($source->id); ?>" <?php echo e(old('source_id') == $source->id? 'selected': ''); ?>><?php echo e($source->source_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="focus-border"></span>
                                        <?php if($errors->has('source_id')): ?>
                                        <span class="invalid-feedback invalid-select" role="alert">
                                            <strong><?php echo e($errors->first('source_id')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                        </div>
                    <?php endif; ?>
                    <div class="row mb-40">
                        <?php if(is_show('photo')): ?>  
                        <div class="col-lg-3">
                            <div class="row no-gutters input-right-icon">
                                <div class="col">
                                    <div class="input-effect sm2_mb_20 md_mb_20">
                                        <input class="primary-input" type="text" id="placeholderPhoto" placeholder="<?php echo app('translator')->get('common.student_photo'); ?>  <?php if(is_required('photo')==true): ?> * <?php endif; ?>"
                                            readonly="">
                                        <span class="focus-border"></span>

                                        <?php if($errors->has('photo')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e(@$errors->first('photo')); ?></strong>
                                            </span>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-auto">
                                    <button class="primary-btn-small-input" type="button">
                                        <label class="primary-btn small fix-gr-bg" for="photo"><?php echo app('translator')->get('common.browse'); ?></label>
                                        <input type="file" class="d-none" value="<?php echo e(old('photo')); ?>" name="photo" id="photo">
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?> 
                        <?php if(generalSetting()->with_guardian): ?>
                        <?php if(is_show('guardians_email') || is_show('guardians_phone')): ?>
                        <div class="col-lg-6 text-right">
                            <div class="row">
                                <div class="col-lg-7 text-left" id="parent_info">
                                    <input type="hidden" name="parent_id" value="">

                                </div>
                                
                            </div>

                        </div>
                        <?php endif; ?> 
                        <?php endif; ?> 
                    </div>
                    <?php if(generalSetting()->with_guardian): ?>
                    <input type="hidden" name="staff_parent" id="staff_parent">
                    <!-- Start Sibling Add Modal -->
                    <div class="modal fade admin-query" id="editStudent">
                        <div class="modal-dialog small-modal modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><?php echo app('translator')->get('student.select_sibling'); ?></h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <div class="container-fluid">
                                        <form action="">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="d-flex radio-btn-flex">
                                                        <div class="mr-30">
                                                            <input type="radio" name="subject_type" id="siblingParentRadio" value="sibling" class="common-radio relationButton addParent" checked>
                                                            <label for="siblingParentRadio"><?php echo app('translator')->get('student.From Sibling'); ?></label>
                                                        </div>
                                                       
                                                        <div class="mr-30">
                                                            <input type="radio" name="subject_type" id="staffParentRadio" value="staff" class="common-radio relationButton addParent">
                                                            <label for="staffParentRadio"><?php echo app('translator')->get('student.From Staff'); ?></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-25" id="siblingParent">
                                                <div class="col-lg-12">

                                                    <div class="row">
                                                        <div class="col-lg-12" id="sibling_required_error">

                                                        </div>
                                                    </div>
                                                    <div class="row mt-25">
                                                        <div class="col-lg-12" id="sibling_class_div">
                                                            <select class="niceSelect w-100 bb" name="sibling_class" id="select_sibling_class">
                                                                <option data-display="<?php echo app('translator')->get('student.class'); ?> *" value=""><?php echo app('translator')->get('student.class'); ?> *</option>
                                                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($class->id); ?>" <?php echo e(old('sibling_class') == $class->id? 'selected': ''); ?> ><?php echo e($class->class_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row mt-25">
                                                        <div class="col-lg-12" id="sibling_section_div">
                                                            <select class="niceSelect w-100 bb" name="sibling_section" id="select_sibling_section">
                                                                <option data-display="<?php echo app('translator')->get('common.section'); ?> *" value=""><?php echo app('translator')->get('common.section'); ?> *</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-25">
                                                        <div class="col-lg-12" id="sibling_name_div">
                                                            <select class="niceSelect w-100 bb" name="select_sibling_name" id="select_sibling_name">
                                                                <option data-display="<?php echo app('translator')->get('student.sibling'); ?> *" value=""><?php echo app('translator')->get('student.sibling'); ?> *</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="row mt-25 d-none" id="staffParent">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="col-lg-12" id="staff_class_div">
                                                            <select class="niceSelect w-100 bb"  id="select_staff_parent">
                                                                <option data-display="<?php echo app('translator')->get('hr.select_staff'); ?> *" value=""><?php echo app('translator')->get('hr.select_staff'); ?> *</option>
                                                                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($staff->id); ?>" ><?php echo e($staff->full_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12 text-center mt-40">
                                                    <div class="mt-40 d-flex justify-content-between">
                                                        <button type="button" class="primary-btn tr-bg" data-dismiss="modal"><?php echo app('translator')->get('common.cancel'); ?></button>

                                                        <button class="primary-btn fix-gr-bg" id="save_button_parent" data-dismiss="modal" type="button"><?php echo app('translator')->get('common.save_information'); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- End Sibling Add Modal -->
                    <div class="parent_details" id="parent_details">
                        
                        <div class="row mt-40">
                            <div class="col-lg-12">
                                <div class="main-title">
                                    <h4 class="stu-sub-head"><?php echo app('translator')->get('student.parents_and_guardian_info'); ?> </h4>
                                </div>
                            </div>
                        </div>

            

                    
                  
                        <div class="row mb-30 mt-30">
                        
                           
                     
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input form-control<?php echo e($errors->has('guardians_name') ? ' is-invalid' : ''); ?>" type="text" name="guardians_name" id="guardians_name" value="<?php echo e(old('guardians_name')); ?>">
                                    <label><?php echo app('translator')->get('student.guardian_name'); ?>  <?php if(is_required('guardians_name')==true): ?> <span> *</span> <?php endif; ?> </label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('guardians_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('guardians_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if(is_show('guardians_email') || is_show('guardians_phone')): ?> 
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                        <select class="niceSelect w-100 bb" name="relation">
                           
                                        <option data-display="Select Relation" >Relation</option>
                                        <option value="Father">Father</option>
                                        <option value="Mother">Mother</option>
                                        <option value="Brother">Brother</option>
                                        <option value="Sister">Sister</option>
                                    
                                    </select>
                                    <label><?php echo app('translator')->get('student.relation_with_guardian'); ?> <?php if(is_required('relation')==true): ?> <span> *</span> <?php endif; ?> </label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('relation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('relation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <?php if(is_show('guardians_email')): ?> 
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input oninput="emailCheck(this)" class="primary-input form-control<?php echo e($errors->has('guardians_email') ? ' is-invalid' : ''); ?>" type="text" name="guardians_email" id="guardians_email" vvalue="<?php echo e($student->parents->guardians_email); ?>">
                                    <label><?php echo app('translator')->get('student.guardian_email'); ?> <?php if(is_required('guardians_email')==true): ?> <span> *</span> <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('guardians_email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('guardians_email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <?php if(is_show('guardians_photo')): ?> 
                            <div class="col-lg-3">
                                <div class="row no-gutters input-right-icon">
                                    <div class="col">
                                        <div class="input-effect sm2_mb_20 md_mb_20">
                                            <input class="primary-input" type="text" id="placeholderGuardiansName" placeholder="<?php echo app('translator')->get('student.photo'); ?> <?php if(is_required('guardians_photo')==true): ?> * <?php endif; ?>"
                                                readonly="">
                                            <span class="focus-border"></span>
                                            <?php if($errors->has('guardians_photo')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e(@$errors->first('guardians_photo')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <button class="primary-btn-small-input" type="button">
                                            <label class="primary-btn small fix-gr-bg" for="guardians_photo"><?php echo app('translator')->get('common.browse'); ?></label>
                                            <input type="file" class="d-none" name="guardians_photo" id="guardians_photo">
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?> 
                        </div>
                        <div class="row mb-30">
                            <?php if(is_show('guardians_phone')): ?> 
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input form-control<?php echo e($errors->has('guardians_phone') ? ' is-invalid' : ''); ?>" type="text" name="guardians_phone" id="guardians_phone" value="<?php echo e($student->parents->guardians_mobile); ?>">
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('guardians_phone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e(@$errors->first('guardians_phone')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <?php if(is_show('guardians_occupation')): ?> 
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input" type="text" name="guardians_occupation" id="guardians_occupation"  value="<?php echo e($student->parents->guardians_occupation); ?>">
                                    <label><?php echo app('translator')->get('student.guardian_occupation'); ?> <?php if(is_required('guardians_occupation')==true): ?> <span> *</span> <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('guardians_occupation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e(@$errors->first('guardians_occupation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                       
                       
                            <?php if(is_show('guardians_address')): ?>
                            <div class="col-lg-4">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input class="primary-input" type="text" name="guardians_address" id="guardians_address"  value="<?php echo e($student->parents->guardians_address); ?>"> 
                             
                                      <label><?php echo app('translator')->get('student.guardian_address'); ?> <?php if(is_required('guardians_address')==true): ?> <span> *</span> <?php endif; ?> </label>
                                    <span class="focus-border textarea"></span>
                                   <?php if($errors->has('guardians_address')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('guardians_address')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <?php endif; ?> 


                    <div class="row mt-40">
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h4 class="stu-sub-head"><?php echo app('translator')->get('student.student_address_info'); ?></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-30 mt-30">
                        
                        <?php if(is_show('phone_number')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input oninput="phoneCheck(this)" class="primary-input form-control<?php echo e($errors->has('phone_number') ? ' is-invalid' : ''); ?>" type="text" name="phone_number" value="<?php echo e($student->mobile); ?>">
                                   
                                <label><?php echo app('translator')->get('student.phone_number'); ?>  <?php if(is_required('phone_number')==true): ?> <span> *</span> <?php endif; ?></label>
                              
                                <span class="focus-border"></span>
                                <?php if($errors->has('phone_number')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?> 
                        <?php if(is_show('roll_number')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input oninput="numberCheck(this)" class="primary-input" type="text" id="roll_number" name="roll_number"   value="<?php echo e($student->roll_number); ?>">
                                <label> <?php echo e(moduleStatusCheck('Lead')==true ? __('lead::lead.id_number') : __('student.roll')); ?>

                                     <?php if(is_required('roll_number')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border"></span>
                                <span class="text-danger" id="roll-error" role="alert">
                                    <strong></strong>
                                </span>
                                <?php if($errors->has('roll_number')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('roll_number')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <?php endif; ?> 
                          <?php if(is_show('email_address')): ?>
                            <div class="col-lg-3">
                                <div class="input-effect sm2_mb_20 md_mb_20">
                                    <input oninput="emailCheck(this)" class="primary-input form-control<?php echo e($errors->has('email_address') ? ' is-invalid' : ''); ?>" type="text" name="email_address" value="<?php echo e($student->email); ?>">
                                   <label><?php echo app('translator')->get('common.email_address'); ?>  <?php if(is_required('email_address')==true): ?> <span> *</span> <?php endif; ?></label>
                                    <span class="focus-border"></span>
                                    <?php if($errors->has('email_address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email_address')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?> 
                           
                        <?php if(is_show('current_address')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                   <input class="primary-input form-control<?php echo e($errors->has('current_address') ? ' is-invalid' : ''); ?>" type="text" name="current_address" value="<?php echo e($student->current_address); ?>">
                                <label><?php echo app('translator')->get('student.current_address'); ?> <?php if(is_required('current_address')==true): ?> <span> *</span> <?php endif; ?> </label>
                                <span class="focus-border"></span>
                               <?php if($errors->has('current_address')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('current_address')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?> 
                      
                       
                       
                    </div>
                    <div class="row mb-30 mt-30">
                        <?php if(is_show('permanent_address')): ?>
                        <div class="col-lg-3">
                           <div class="input-effect sm2_mb_20 md_mb_20">
                                 <input class="primary-input form-control<?php echo e($errors->has('permanent_address') ? ' is-invalid' : ''); ?>" type="text" name="permanent_address" value="<?php echo e($student->permanent_address); ?>">
                         
                                  <label><?php echo app('translator')->get('student.permanent_address'); ?>  <?php if(is_required('permanent_address')==true): ?> <span> *</span> <?php endif; ?> </label>
                               <span class="focus-border"></span>
                              <?php if($errors->has('permanent_address')): ?>
                               <span class="invalid-feedback">
                                   <strong><?php echo e($errors->first('permanent_address')); ?></strong>
                               </span>
                               <?php endif; ?>
                           </div>
                       </div>
                       <?php endif; ?> 
                 
                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                               <input class="primary-input form-control<?php echo e($errors->has('othercontact') ? ' is-invalid' : ''); ?>" type="text" name="othercontact" value="<?php echo e($student->othercontact); ?>"> 
                            <label><?php echo app('translator')->get('student.othercontact'); ?> <?php if(is_required('othercontact')==true): ?> <span> *</span> <?php endif; ?> </label>
                            <span class="focus-border"></span>
                           <?php if($errors->has('othercontact')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('othercontact')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                  
              
                     <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              <input class="primary-input form-control<?php echo e($errors->has('area') ? ' is-invalid' : ''); ?>" type="text" name="area" value="<?php echo e($student->area); ?>"> 
                      
                               <label><?php echo app('translator')->get('student.area'); ?>  <?php if(is_required('area')==true): ?> <span> *</span> <?php endif; ?> </label>
                            <span class="focus-border"></span>
                           <?php if($errors->has('area')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('area')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
             
                   
                   
                </div> 
             
                 
              

                <script type="text/javascript">
                    function changeFunc() {
                        var selectBox = document.getElementById("selectBox");
                        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
                        if (selectedValue == "YES") {
                            $('#textboxes').show();
                        } else {
                           
                            $('#textboxes').hide();
                        }
                    }


                    function changeConfirmationFunc() {
                        var selectBox = document.getElementById("selectConfirmationBox");
                        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
                        if (selectedValue == "YES") {
                            $('#confirmationtextboxes').show();
                        } else {
                           
                            $('#confirmationtextboxes').hide();
                        }
                    }


                    function changemarriageFunc() {
                        var selectBox = document.getElementById("selectMarriageBox");
                        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
                        if (selectedValue == "YES") {
                            $('#marriagetextboxes').show();
                        } else {
                           
                            $('#marriagetextboxes').hide();
                        }
                    }

                    
                    function changefamilyFunc() {
                        var selectBox = document.getElementById("selectFamilyBox");
                        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
                        if (selectedValue == "YES") {
                            $('#familytextboxes').show();
                        } else {
                           
                            $('#familytextboxes').hide();
                        }
                    }

                    function changestudentFunc() {
                        var selectBox = document.getElementById("selectStudentBox");
                        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
                        if (selectedValue == "YES") {
                            $('#studenttextboxes').show();
                        } else {
                           
                            $('#studenttextboxes').hide();
                        }
                    }
                </script>
                <div class="row mb-40 mt-40">
                               
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <label><?php echo app('translator')->get('student.baptism'); ?> <?php if(is_required('ifsc_code')==true): ?> <span> *</span> <?php endif; ?></label>
                      
                            <select class="niceSelect w-100 bb" name="baptism_status" id="selectBox" onchange="changeFunc();">
                       
                                <option data-display="Select Baptism Status" >BAPTIZED?</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>

                            </select>
                               <span class="focus-border"></span>
                            <?php if($errors->has('ifsc_code')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('ifsc_code')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 


                               
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <label><?php echo app('translator')->get('student.confirmation'); ?> <?php if(is_required('confirm')==true): ?> <span> *</span> <?php endif; ?></label>
                      
                            <select class="niceSelect w-100 bb" name="confirmation_status" id="selectConfirmationBox" onchange="changeConfirmationFunc();">
                       
                                <option data-display="Confirmation Status" >CONFIRMED?</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>

                            </select>
                               <span class="focus-border"></span>
                            <?php if($errors->has('confirmation')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 


                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <label><?php echo app('translator')->get('student.family'); ?> <?php if(is_required('family')==true): ?> <span> *</span> <?php endif; ?></label>
                      
                            <select class="niceSelect w-100 bb" name="family_status" id="selectFamilyBox" onchange="changefamilyFunc();">
                       
                                <option data-display="Are you a family man/woman?" >Family?</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>

                            </select>
                               <span class="focus-border"></span>
                            <?php if($errors->has('family')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('family')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 


                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <label><?php echo app('translator')->get('student.marriage'); ?> <?php if(is_required('marriage')==true): ?> <span> *</span> <?php endif; ?></label>
                      
                            <select class="niceSelect w-100 bb" name="marriage_status" id="selectMarriageBox" onchange="changemarriageFunc();">
                       
                                <option data-display="Are you married?" >Married?</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>

                            </select>
                               <span class="focus-border"></span>
                            <?php if($errors->has('marriage')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('marriage')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <label><?php echo app('translator')->get('student.student'); ?> <?php if(is_required('student')==true): ?> <span> *</span> <?php endif; ?></label>
                      
                            <select class="niceSelect w-100 bb" name="student_status" id="selectStudentBox" onchange="changestudentFunc();">
                       
                                <option data-display="Select Student Status" >Student?</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>

                            </select>
                               <span class="focus-border"></span>
                            <?php if($errors->has('student')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('student')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 
                <div>

                    
                    <div class="row  mt-40" style="display: none" id="textboxes">
                 
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h4 class="stu-sub-head"><?php echo app('translator')->get('student.baptism_details'); ?></h4>
                            </div>
                        </div>
                   
                   
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              <input class="primary-input date form-control<?php echo e($errors->has('date_of_baptism') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                            name="date_of_baptism" value="<?php echo e(old('date_of_baptism')); ?>" autocomplete="off">
                            <label><?php echo app('translator')->get('student.date_of_baptism'); ?>  <?php if(is_required('date_of_baptism')==true): ?> <span> *</span> <?php endif; ?></label>
                          
                            <span class="focus-border"></span>
                            <?php if($errors->has('date_of_baptism')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('date_of_baptism')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                  
                 
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="place_of_baptism" name="place_of_baptism"  value="<?php echo e(old('place_of_baptism')); ?>">
                            <label><?php echo app('translator')->get('student.place_of_baptism'); ?>  <?php if(is_required('place_of_baptism')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('place_of_baptism')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('place_of_baptism')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
    
                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              
                            <select class="niceSelect w-100 bb" name="baptism_type">
                           
                                <option data-display="Select Type of Baptism" >Select Type of Baptism</option>
                                <option value="Aspersion(Sprinkling)">Aspersion(Sprinkling)</option>
                                <option value="Immersion(submerging)">Immersion(submerging)</option>
                                <option value="Affusion(pouring water)">Affusion(pouring water)</option>
                                <option value="Other">Other</option>
                            </select>
                            <label><?php echo app('translator')->get('student.baptism_type'); ?>  <?php if(is_required('baptism_type')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('baptism_type')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('baptism_type')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                       
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="baptism_cert_no" name="baptism_cert_no"  value="<?php echo e(old('baptism_cert_no')); ?>">
                            <label><?php echo app('translator')->get('student.baptism_cert_no'); ?>  <?php if(is_required('baptism_cert_no')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('baptism_cert_no')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('baptism_cert_no')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="baptism_off_minister" name="baptism_off_minister"  value="<?php echo e(old('baptism_off_minister')); ?>">
                            <label><?php echo app('translator')->get('student.baptism_off_minister'); ?>  <?php if(is_required('baptism_off_minister')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('baptism_off_minister')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('baptism_off_minister')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                   
                </div>

      
                <div class="row  mt-40"  style="display: none" id="confirmationtextboxes">
                    <div class="col-lg-12">
                        <div class="main-title">
                            <h4 class="stu-sub-head"><?php echo app('translator')->get('student.confirmation_details'); ?></h4>
                        </div>
                    </div>
              
                <div class="row mb-30 mt-40">
                        
                                   
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              <input class="primary-input date form-control<?php echo e($errors->has('date_of_confirmation') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                            name="date_of_confirmation" value="<?php echo e(old('date_of_confirmation')); ?>" autocomplete="off">
                            <label><?php echo app('translator')->get('student.date_of_confirmation'); ?>  <?php if(is_required('date_of_confirmation')==true): ?> <span> *</span> <?php endif; ?></label>
                          
                            <span class="focus-border"></span>
                            <?php if($errors->has('date_of_confirmation')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('date_of_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="ageconfirmed" name="ageconfirmed"  value="<?php echo e(old('ageconfirmed')); ?>">
                            <label><?php echo app('translator')->get('student.ageconfirmed'); ?>  <?php if(is_required('ageconfirmed')==true): ?> <span> *</span> <?php endif; ?></label>
                          
                            <span class="focus-border"></span>
                            <?php if($errors->has('ageconfirmed')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('ageconfirmed')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                  
                 
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="place_of_confirmation" name="place_of_confirmation"  value="<?php echo e(old('place_of_confirmation')); ?>">
                            <label><?php echo app('translator')->get('student.place_of_confirmation'); ?>  <?php if(is_required('place_of_confirmation')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('place_of_confirmation')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('place_of_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
    
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              
                            <input   class="primary-input" type="text" id="bibleverseused" name="bibleverseused"  value="<?php echo e(old('bibleverseused')); ?>">
                       
                            <label><?php echo app('translator')->get('student.bibleverseused'); ?>  <?php if(is_required('bibleverseused')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('bibleverseused')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('bibleverseused')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                       
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="confirmation_cert_no" name="confirmation_cert_no"  value="<?php echo e(old('confirmation_cert_no')); ?>">
                            <label><?php echo app('translator')->get('student.confirmation_cert_no'); ?>  <?php if(is_required('confirmation_cert_no')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('confirmation_cert_no')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('confirmation_cert_no')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="confirmation_off_minister" name="confirmation_off_minister"  value="<?php echo e(old('confirmation_off_minister')); ?>">
                            <label><?php echo app('translator')->get('student.confirmation_off_minister'); ?>  <?php if(is_required('confirmation_off_minister')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('confirmation_off_minister')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('confirmation_off_minister')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                   
                </div>
            </div>
            <div class="row  mt-40" style="display: none" id="marriagetextboxes">
          
                    <div class="col-lg-12">
                        <div class="main-title">
                            <h4 class="stu-sub-head"><?php echo app('translator')->get('student.marriage_details'); ?></h4>
                        </div>
                    </div>
            
                <div class="row mb-30 mt-30">
                        
                  
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              <input class="primary-input date form-control<?php echo e($errors->has('date_of_marriage') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                            name="date_of_marriage" value="<?php echo e(old('date_of_marriage')); ?>" autocomplete="off">
                            <label><?php echo app('translator')->get('student.date_of_marriage'); ?>  <?php if(is_required('date_of_marriage')==true): ?> <span> *</span> <?php endif; ?></label>
                          
                            <span class="focus-border"></span>
                            <?php if($errors->has('date_of_marriage')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('date_of_marriage')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                  
                 
                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="place_of_marriage" name="place_of_marriage"  value="<?php echo e(old('place_of_marriage')); ?>">
                            <label><?php echo app('translator')->get('student.place_of_marriage'); ?>  <?php if(is_required('place_of_marriage')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('place_of_marriage')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('place_of_marriage')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
    
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                              
                            <select class="niceSelect w-100 bb" name="marriage_type">
                           
                                <option data-display="Select Type of Marriage" >Select Type of Marriage</option>
                                <option value="TRADITIONAL/CUSTOMARY">TRADITIONAL/CUSTOMARY</option>
                                <option value="ORDINANCE">ORDINANCE</option>
                                <option value="Other">Other</option>
                            </select>
                            <label><?php echo app('translator')->get('student.marriage_type'); ?>  <?php if(is_required('marriage_type')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('marriage_type')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('marriage_type')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                       
                    <div class="col-lg-3">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="marriage_cert_no" name="marriage_cert_no"  value="<?php echo e(old('marriage_cert_no')); ?>">
                            <label><?php echo app('translator')->get('student.marriage_cert_no'); ?>  <?php if(is_required('marriage_cert_no')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('marriage_cert_no')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('marriage_cert_no')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="marriage_off_minister" name="marriage_off_minister"  value="<?php echo e(old('marriage_off_minister')); ?>">
                            <label><?php echo app('translator')->get('student.marriage_off_minister'); ?>  <?php if(is_required('marriage_off_minister')==true): ?> <span> *</span> <?php endif; ?></label>
                       
                            <span class="focus-border"></span>
                            <span class="text-danger" id="roll-error" role="alert">
                                <strong></strong>
                            </span>
                            <?php if($errors->has('marriage_off_minister')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('marriage_off_minister')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                   
                </div>
                

            </div>

            <div class="row  mt-40" style="display: none" id="familytextboxes">
                    <div class="col-lg-12">
                        <div class="main-title">
                            <h4 class="stu-sub-head"><?php echo app('translator')->get('student.family_details'); ?></h4>
                        </div>
                    </div>
            

                <div class="row mb-30 mt-30">
                 
                    <div class="col-lg-3">
                       <div class="input-effect sm2_mb_20 md_mb_20">
                        <input   class="primary-input" type="text" id="spouse_name" name="spouse_name"  value="<?php echo e(old('spouse_name')); ?>">
                            <label><?php echo app('translator')->get('student.spouse_name'); ?><?php if(is_required('spouse_name')==true): ?> <span> *</span> <?php endif; ?></label>
                            <span class="focus-border textarea"></span>
                            <?php if($errors->has('spouse_name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('spouse_name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
            
                  
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                                  <input class="primary-input date form-control<?php echo e($errors->has('spouse_date_of_birth') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                            name="spouse_date_of_birth" value="<?php echo e(old('spouse_date_of_birth')); ?>" autocomplete="off">
                            <label><?php echo app('translator')->get('student.spouse_date_of_birth'); ?> <?php if(is_required('spouse_date_of_birth')==true): ?> <span> *</span> <?php endif; ?></label>
                            <span class="focus-border textarea"></span>
                            <?php if($errors->has('spouse_date_of_birth')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('spouse_date_of_birth')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="spouse_chucrh" name="spouse_chucrh"  value="<?php echo e(old('school_telephone')); ?>">
                   
                            <label><?php echo app('translator')->get('student.spouse_chucrh'); ?> <?php if(is_required('spouse_chucrh')==true): ?> <span> *</span> <?php endif; ?></label>
                            <span class="focus-border textarea"></span>
                            <?php if($errors->has('spouse_chucrh')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('spouse_chucrh')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                  
                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="child_name1" name="child_name1"  value="<?php echo e(old('child_name1')); ?>">
                   
                                 <label><?php echo app('translator')->get('student.child_name1'); ?> <?php if(is_required('child_name1')==true): ?> <span> *</span> <?php endif; ?></label>
                            <span class="focus-border textarea"></span>
                            <?php if($errors->has('child_name1')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('child_name1')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                 

                    <div class="col-lg-2">
                        <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="child_name2" name="child_name2"  value="<?php echo e(old('child_name2')); ?>">
                               <label><?php echo app('translator')->get('student.child_name2'); ?> <?php if(is_required('child_name2')==true): ?> <span> *</span> <?php endif; ?></label>
                            <span class="focus-border textarea"></span>
                            <?php if($errors->has('child_name2')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('child_name2')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

  
                </div>
            </div>


                    <div class="row mt-40" style="display: none" id="studenttextboxes">
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h4 class="stu-sub-head"><?php echo app('translator')->get('student.school_details'); ?></h4>
                            </div>
                        </div>
                  

                    <div class="row mb-30 mt-30">
                        <?php if(is_show('previous_school_details')): ?>
                        <div class="col-lg-3">
                           <div class="input-effect sm2_mb_20 md_mb_20">
                            <input   class="primary-input" type="text" id="previous_school_details" name="student_school_name"  value="<?php echo e(old('previous_school_details')); ?>">
                                <label><?php echo app('translator')->get('student.previous_school_details'); ?><?php if(is_required('previous_school_details')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border textarea"></span>
                                <?php if($errors->has('previous_school_details')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('previous_school_details')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                      
                        <div class="col-lg-2">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                      <input class="primary-input date form-control<?php echo e($errors->has('school_admission_date') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                                name="school_admission_date" value="<?php echo e(old('school_admission_date')); ?>" autocomplete="off">
                                <label><?php echo app('translator')->get('student.school_admission_date'); ?> <?php if(is_required('school_admission_date')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border textarea"></span>
                                <?php if($errors->has('school_admission_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('school_admission_date')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                      <input class="primary-input date form-control<?php echo e($errors->has('school_completion_date') ? ' is-invalid' : ''); ?>" id="startDate" type="text"
                                name="school_completion_date" value="<?php echo e(old('school_completion_date')); ?>" autocomplete="off">
                                <label><?php echo app('translator')->get('student.school_completion_date'); ?> <?php if(is_required('school_completion_date')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border textarea"></span>
                                <?php if($errors->has('school_completion_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('school_completion_date')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                      
                        <div class="col-lg-2">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input   class="primary-input" type="text" id="school_telephone" name="school_telephone"  value="<?php echo e(old('school_telephone')); ?>">
                       
                                     <label><?php echo app('translator')->get('student.school_telephone'); ?> <?php if(is_required('school_telephone')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border textarea"></span>
                                <?php if($errors->has('school_telephone')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('school_telephone')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                     

                        <div class="col-lg-2">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <input   class="primary-input" type="text" id="school_location" name="school_location"  value="<?php echo e(old('school_location')); ?>">
                                   <label><?php echo app('translator')->get('student.school_location'); ?> <?php if(is_required('school_location')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border textarea"></span>
                                <?php if($errors->has('school_location')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('school_location')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                   

                </div>



                  
                  <div class="row  mt-30">
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h4 class="stu-sub-head"><?php echo app('translator')->get('student.group_details'); ?></h4>
                            </div>
                        </div>
                       
                    </div>
                     <div class="row mt-30">
                        <?php if(is_show('document_file_1')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <select class="niceSelect w-100 bb" name="document_title_1"  value="<?php echo e($student->document_title_1); ?>">
                                    <option data-display="Select Group" >Select Group in Church</option>
                                    <option value="CHOIR UNION">CHOIR UNION</option>
                                    <option value="SHEKINA">SHEKINA</option>
                                    <option value="BSPG">BIBLE STUDIES AND PRAYER GROUP</option>
                                    <option value="SINGING BAND">SINGING BAND</option>
                                    <option value="MEDIA TEAM">MEDIA TEAM</option>
                                </select>
                                <label><?php echo app('translator')->get('student.document_01_title'); ?> <?php if(is_required('document_file_1')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('document_title_1')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('document_title_1')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(is_show('document_file_2')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                               
                                <select class="niceSelect w-100 bb" name="document_title_2"  value="<?php echo e($student->document_title_2); ?>">
                                    <option data-display="Select Group" >Select Group in Church</option>
                                    <option value="CHOIR UNION">CHOIR UNION</option>
                                    <option value="SHEKINA">SHEKINA</option>
                                    <option value="BSPG">BIBLE STUDIES AND PRAYER GROUP</option>
                                    <option value="SINGING BAND">SINGING BAND</option>
                                    <option value="MEDIA TEAM">MEDIA TEAM</option>
                                </select>
                                <label><?php echo app('translator')->get('student.document_02_title'); ?> <?php if(is_required('document_file_2')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('document_title_2')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('document_title_2')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(is_show('document_file_3')): ?>
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <select class="niceSelect w-100 bb" name="document_title_3"  value="<?php echo e($student->document_title_3); ?>">
                                    <option data-display="Select Group" >Select Group in Church</option>
                                    <option value="CHOIR UNION">CHOIR UNION</option>
                                    <option value="SHEKINA">SHEKINA</option>
                                    <option value="BSPG">BIBLE STUDIES AND PRAYER GROUP</option>
                                    <option value="SINGING BAND">SINGING BAND</option>
                                    <option value="MEDIA TEAM">MEDIA TEAM</option>
                                </select>
                                <label><?php echo app('translator')->get('student.document_03_title'); ?> <?php if(is_required('document_file_3')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('document_title_3')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('document_title_3')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                     
                        <div class="col-lg-3">
                            <div class="input-effect sm2_mb_20 md_mb_20">
                                <select class="niceSelect w-100 bb" name="document_title_4"  value="<?php echo e($student->document_title_4); ?>">
                                    <option data-display="Select Group" >Select Group in Church</option>
                                    <option value="CHOIR UNION">CHOIR UNION</option>
                                    <option value="SHEKINA">SHEKINA</option>
                                    <option value="BSPG">BIBLE STUDIES AND PRAYER GROUP</option>
                                    <option value="SINGING BAND">SINGING BAND</option>
                                    <option value="MEDIA TEAM">MEDIA TEAM</option>
                                </select>
                                <label><?php echo app('translator')->get('student.document_04_title'); ?> <?php if(is_required('document_file_4')==true): ?> <span> *</span> <?php endif; ?></label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('document_title_4')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('document_title_4')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                    </div>
              
                </div>
            </div>










 
                        
                        <div class="row mt-5">
                            <div class="col-lg-12 text-center">
                                <button class="primary-btn fix-gr-bg submit">
                                    <span class="ti-check"></span>
                                    <?php echo app('translator')->get('student.update_student'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</section>


<div class="modal fade admin-query" id="removeSiblingModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo app('translator')->get('student.remove'); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <div class="text-center">
                        <h4><?php echo app('translator')->get('student.are_you'); ?></h4>
                    </div>

                    <div class="mt-40 d-flex justify-content-between">
                        <button type="button" class="primary-btn tr-bg" data-dismiss="modal"><?php echo app('translator')->get('common.cancel'); ?></button>
                        <button type="button" class="primary-btn fix-gr-bg" data-dismiss="modal" id="yesRemoveSibling"><?php echo app('translator')->get('common.delete'); ?></button>
                        
                    </div>
                </div>

            </div>
        </div>
    </div>


 
 <input type="text" id="STurl" value="<?php echo e(route('student_update_pic',$student->id)); ?>" hidden>
 <div class="modal" id="LogoPic">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Crop Image And Upload</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div id="resize"></div>
                <button class="btn rotate float-lef" data-deg="90" > 
                <i class="ti-back-right"></i></button>
                <button class="btn rotate float-right" data-deg="-90" > 
                <i class="ti-back-left"></i></button>
                <hr>                
                <a href="javascript:;" class="primary-btn fix-gr-bg pull-right" id="upload_logo">Crop</a>
            </div>
        </div>
    </div>
</div>


 

 <div class="modal" id="FatherPic">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Crop Image And Upload</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div id="fa_resize"></div>
                <button class="btn rotate float-lef" data-deg="90" > 
                <i class="ti-back-right"></i></button>
                <button class="btn rotate float-right" data-deg="-90" > 
                <i class="ti-back-left"></i></button>
                <hr>                
                <a href="javascript:;" class="primary-btn fix-gr-bg pull-right" id="FatherPic_logo">Crop</a>
            </div>
        </div>
    </div>
</div>

 

 <div class="modal" id="MotherPic">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Crop Image And Upload</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div id="ma_resize"></div>
                <button class="btn rotate float-lef" data-deg="90" > 
                <i class="ti-back-right"></i></button>
                <button class="btn rotate float-right" data-deg="-90" > 
                <i class="ti-back-left"></i></button>
                <hr>                
                <a href="javascript:;" class="primary-btn fix-gr-bg pull-right" id="Mother_logo">Crop</a>
            </div>
        </div>
    </div>
</div>

 

 <div class="modal" id="GurdianPic">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Crop Image And Upload</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div id="Gu_resize"></div>
                <button class="btn rotate float-lef" data-deg="90" > 
                <i class="ti-back-right"></i></button>
                <button class="btn rotate float-right" data-deg="-90" > 
                <i class="ti-back-left"></i></button>
                <hr>
                
                <a href="javascript:;" class="primary-btn fix-gr-bg pull-right" id="Gurdian_logo">Crop</a>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('public/backEnd/')); ?>/js/croppie.js"></script>
<script src="<?php echo e(asset('public/backEnd/')); ?>/js/st_addmision.js"></script>
<script>
    $(document).ready(function(){
        
        $(document).on('change','.cutom-photo',function(){
            let v = $(this).val();
            let v1 = $(this).data("id");
            console.log(v,v1);
            getFileName(v, v1);

        });

        function getFileName(value, placeholder){
            if (value) {
                var startIndex = (value.indexOf('\\') >= 0 ? value.lastIndexOf('\\') : value.lastIndexOf('/'));
                var filename = value.substring(startIndex);
                if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                    filename = filename.substring(1);
                }
                $(placeholder).attr('placeholder', '');
                $(placeholder).attr('placeholder', filename);
            }
        }

        
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pcgdb\resources\views/backEnd/studentInformation/student_edit.blade.php ENDPATH**/ ?>