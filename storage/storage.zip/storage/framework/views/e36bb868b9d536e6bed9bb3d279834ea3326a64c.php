<?php
    $school_config = schoolConfig();
    $isSchoolAdmin = Session::get('isSchoolAdmin');
?>
        <!-- sidebar part here -->
<nav id="sidebar" class="sidebar">

    <div class="sidebar-header update_sidebar">
        <?php if(Auth::user()->role_id != 2 && Auth::user()->role_id != 3): ?>
            <?php if(userPermission(1)): ?>
                <?php if(moduleStatusCheck('Saas') == true && Auth::user()->is_administrator == 'yes' && Session::get('isSchoolAdmin') == false && Auth::user()->role_id == 1): ?>
                    <a href="<?php echo e(route('superadmin-dashboard')); ?>" id="superadmin-dashboard">
                        <?php else: ?>
                            <a href="<?php echo e(route('admin-dashboard')); ?>" id="admin-dashboard">
                                <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/')); ?>" id="admin-dashboard">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('/')); ?>" id="admin-dashboard">
                                                <?php endif; ?>
                                                <?php if(!is_null($school_config->logo)): ?>
                                                    <img src="<?php echo e(asset($school_config->logo)); ?>" alt="logo">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('public/uploads/settings/logo.png')); ?>"
                                                         alt="logo">
                                                <?php endif; ?>
                                            </a>
                                            <a id="close_sidebar" class="d-lg-none">
                                                <i class="ti-close"></i>
                                            </a>

    </div>
    <?php if(Auth::user()->is_saas == 0): ?>

        <ul class="list-unstyled components" id="sidebar_menu">
            <input type="hidden" name="" id="default_position" value="<?php echo e(menuPosition('is_submit')); ?>">
            <?php if(Auth::user()->role_id != 2 && Auth::user()->role_id != 3): ?>
                <?php if(userPermission(1)): ?>
                    <li>
                        <?php if(moduleStatusCheck('Saas') == true && Auth::user()->is_administrator == 'yes' && Session::get('isSchoolAdmin') == false && Auth::user()->role_id == 1): ?>
                            <a href="<?php echo e(route('superadmin-dashboard')); ?>" id="superadmin-dashboard">
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin-dashboard')); ?>" id="admin-dashboard">
                                        <?php endif; ?>
                                        <div class="nav_icon_small">
                                            <span class="flaticon-speedometer"></span>
                                        </div>
                                        <div class="nav_title">
                                            <?php echo app('translator')->get('common.dashboard'); ?>
                                        </div>

                                    </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(moduleStatusCheck('InfixBiometrics') == true && Auth::user()->role_id == 1): ?>
                <?php echo $__env->make('infixbiometrics::menu.InfixBiometrics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            




            
            <?php if(isSubscriptionEnabled() && Auth::user()->is_administrator != 'yes' && Auth::user()->role_id == 1): ?>
                <?php echo $__env->make('saas::menu.SaasSubscriptionSchool', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            
            <?php if(moduleStatusCheck('Saas') == true && Auth::user()->is_administrator == 'yes' && Session::get('isSchoolAdmin') == false && Auth::user()->role_id == 1): ?>
                <?php echo $__env->make('saas::menu.Saas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                

                <?php if(Auth::user()->role_id != 2 && Auth::user()->role_id != 3): ?>

                    
                    <?php if(moduleStatusCheck('ParentRegistration')): ?>

                        <?php if ($__env->exists('parentregistration::menu.ParentRegistration')) echo $__env->make('parentregistration::menu.ParentRegistration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <?php if(userPermission(11) && menuStatus(11) && isMenuAllowToShow('admin_section')): ?>
                        <li data-position="<?php echo e(menuPosition(11)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-analytics"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('admin.admin_section'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled">
                              
                                <?php if(userPermission(16) && menuStatus(16)): ?>
                                    <li data-position="<?php echo e(menuPosition(16)); ?>">
                                        <a href="<?php echo e(route('visitor')); ?>"><?php echo app('translator')->get('admin.visitor_book'); ?> </a>
                                    </li>
                                <?php endif; ?>

                                <?php if(userPermission(21) && menuStatus(21)): ?>
                                    <li data-position="<?php echo e(menuPosition(21)); ?>">
                                        <a href="<?php echo e(route('complaint')); ?>"><?php echo app('translator')->get('admin.complaint'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(27) && menuStatus(27)): ?>
                                    <li data-position="<?php echo e(menuPosition(27)); ?>">
                                        <a href="<?php echo e(route('postal-receive')); ?>"><?php echo app('translator')->get('admin.postal_receive'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(32) && menuStatus(32)): ?>
                                    <li data-position="<?php echo e(menuPosition(32)); ?>">
                                        <a href="<?php echo e(route('postal-dispatch')); ?>"><?php echo app('translator')->get('admin.postal_dispatch'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(36) && menuStatus(36)): ?>
                                    <li data-position="<?php echo e(menuPosition(36)); ?>">
                                        <a href="<?php echo e(route('phone-call')); ?>"><?php echo app('translator')->get('admin.phone_call_log'); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                          
                                
                            </ul>
                        </li>
                    <?php endif; ?>


      
      <?php if(userPermission(61) && menuStatus(61) && isMenuAllowToShow('student_info')): ?>
      <li data-position="<?php echo e(menuPosition(61)); ?>" class="sortable_li">
          <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
              <div class="nav_icon_small">
                  <span class="flaticon-reading"></span>
              </div>
              <div class="nav_title">
                  <?php echo app('translator')->get('student.student_information'); ?>
              </div>
          </a>
          <ul class="list-unstyled" id="subMenuStudent">
          
              <?php if(userPermission(62) && menuStatus(62)): ?>
                  <li data-position="<?php echo e(menuPosition(62)); ?>">
                      <a href="<?php echo e(route('student_admission')); ?>"><?php echo app('translator')->get('student.add_student'); ?></a>
                  </li>
              <?php endif; ?>

             
              <?php if(userPermission(64) && menuStatus(64)): ?>
                  <li data-position="<?php echo e(menuPosition(64)); ?>">
                      <a href="<?php echo e(route('student_list')); ?>"> <?php echo app('translator')->get('student.student_list'); ?></a>
                  </li>
              <?php endif; ?>
          
                 
            

                
              
           
              
            
              
              <?php if(userPermission(15209) && menuStatus(15209)): ?>
                  <li data-position="<?php echo e(menuPosition(15209)); ?>">
                      <a href="<?php echo e(route('unassigned_student')); ?>"><?php echo app('translator')->get('student.unassigned_student'); ?></a>
                  </li>
              <?php endif; ?>

              <?php if(userPermission(83) && menuStatus(83)): ?>
              <li data-position="<?php echo e(menuPosition(83)); ?>">
                  <a href="<?php echo e(route('disabled_student')); ?>"><?php echo app('translator')->get('student.disabled_student'); ?></a>
              </li>
              <?php endif; ?>

              <?php if(userPermission(663) && menuStatus(663)): ?>
                  <li data-position="<?php echo e(menuPosition(663)); ?>">
                      <a href="<?php echo e(route('all-student-export')); ?>"><?php echo app('translator')->get('student.student_export'); ?></a>
                  </li>
              <?php endif; ?>

              <?php if(userPermission(950) && menuStatus(950)): ?>
                  <li data-position="<?php echo e(menuPosition(950)); ?>">
                      <a href="<?php echo e(route('notification_time_setup')); ?>"><?php echo app('translator')->get('student.sms_sending_time'); ?></a>
                  </li>
              <?php endif; ?>

              
          </ul>
      </li>
  <?php endif; ?>

 



             
             <?php if(userPermission(61) && menuStatus(61) && isMenuAllowToShow('student_info')): ?>
             <li data-position="<?php echo e(menuPosition(61)); ?>" class="sortable_li">
                 <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                     <div class="nav_icon_small">
                         <span class="flaticon-reading"></span>
                     </div>
                     <div class="nav_title">
                         <?php echo app('translator')->get('member.jy_information'); ?>
                     </div>
                 </a>
                 <ul class="list-unstyled" id="subMenuStudent">
                 
                     <?php if(userPermission(62) && menuStatus(62)): ?>
                         <li data-position="<?php echo e(menuPosition(62)); ?>">
                             <a href="<?php echo e(route('jy_registration_form')); ?>"><?php echo app('translator')->get('student.add_student'); ?></a>
                         </li>
                     <?php endif; ?>

                    
                     <?php if(userPermission(64) && menuStatus(64)): ?>
                         <li data-position="<?php echo e(menuPosition(64)); ?>">
                             <a href="<?php echo e(route('jymember_list')); ?>"> <?php echo app('translator')->get('student.student_list'); ?></a>
                         </li>
                     <?php endif; ?>
                      
                     <?php if(userPermission(15209) && menuStatus(15209)): ?>
                         <li data-position="<?php echo e(menuPosition(15209)); ?>">
                             <a href="<?php echo e(route('unassigned_student')); ?>"><?php echo app('translator')->get('student.unassigned_student'); ?></a>
                         </li>
                     <?php endif; ?>

                     

                 

                      

                     
                 </ul>
             </li>
         <?php endif; ?>

                    
                    <?php if(userPermission(61) && menuStatus(61) && isMenuAllowToShow('student_info')): ?>
                        <li data-position="<?php echo e(menuPosition(61)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-reading"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('member.cs_information'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuStudent">
                            
                                <?php if(userPermission(62) && menuStatus(62)): ?>
                                    <li data-position="<?php echo e(menuPosition(62)); ?>">
                                        <a href="<?php echo e(route('cs_registration_form')); ?>"><?php echo app('translator')->get('student.add_student'); ?></a>
                                    </li>
                                <?php endif; ?>

                               
                                <?php if(userPermission(64) && menuStatus(64)): ?>
                                    <li data-position="<?php echo e(menuPosition(64)); ?>">
                                        <a href="<?php echo e(route('csmember_list')); ?>"> <?php echo app('translator')->get('student.student_list'); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if(userPermission(15209) && menuStatus(15209)): ?>
                                    <li data-position="<?php echo e(menuPosition(15209)); ?>">
                                        <a href="<?php echo e(route('unassigned_student')); ?>"><?php echo app('translator')->get('student.unassigned_student'); ?></a>
                                    </li>
                                <?php endif; ?>

                               

                                <?php if(userPermission(663) && menuStatus(663)): ?>
                                    <li data-position="<?php echo e(menuPosition(663)); ?>">
                                        <a href="<?php echo e(route('all-student-export')); ?>"><?php echo app('translator')->get('student.student_export'); ?></a>
                                    </li>
                                <?php endif; ?>

                              

                                
                            </ul>
                        </li>
                    <?php endif; ?>

                   
                    
                    <?php if(userPermission(245) && menuStatus(245) && isMenuAllowToShow('academics')): ?>
                        <li data-position="<?php echo e(menuPosition(245)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-book"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('academics.academics'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuAcademic">
                                <?php if(moduleStatusCheck('University') == false): ?>
                              
                                    <?php if(userPermission(265) && menuStatus(265)): ?>
                                        <li data-position="<?php echo e(menuPosition(265)); ?>">
                                            <a href="<?php echo e(route('section')); ?>"> <?php echo app('translator')->get('common.section'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(userPermission(261) && menuStatus(261)): ?>
                                        <li data-position="<?php echo e(menuPosition(261)); ?>">
                                            <a href="<?php echo e(route('class')); ?>"> <?php echo app('translator')->get('common.class'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                
                                    <?php if(userPermission(71) && menuStatus(71)): ?>
                                    <li data-position="<?php echo e(menuPosition(71)); ?>">
                                        <a href="<?php echo e(route('student_category')); ?>">
                                            <?php echo app('translator')->get('student.student_category'); ?></a>
                                    </li>
                                     <?php endif; ?>
                                     <?php if(userPermission(76) && menuStatus(76)): ?>
                                     <li data-position="<?php echo e(menuPosition(76)); ?>">
                                         <a href="<?php echo e(route('student_group')); ?>"><?php echo app('translator')->get('student.student_group'); ?></a>
                                     </li>
                                 <?php endif; ?>
                             

                                <?php endif; ?>


                

                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(userPermission(87) && menuStatus(87) && isMenuAllowToShow('study_material')): ?>
                        <li data-position="<?php echo e(menuPosition(87)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-professor"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('study.study_material'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuTeacher">
                                <?php if(userPermission(88) && menuStatus(87)): ?>
                                    <li data-position="<?php echo e(menuPosition(88)); ?>">
                                        <a href="<?php echo e(route('upload-content')); ?>"> <?php echo app('translator')->get('study.upload_content'); ?></a>
                                    </li>
                                <?php endif; ?>
                          
                            
                                <?php if(userPermission(105) && menuStatus(105)): ?>
                                    <li data-position="<?php echo e(menuPosition(105)); ?>">
                                        <a href="<?php echo e(route('other-download-list')); ?>"><?php echo app('translator')->get('study.other_download'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

         
                    


                    <?php if(moduleStatusCheck('FeesCollection') == true && isMenuAllowToShow('fees')): ?>
                        <?php echo $__env->make('feescollection::menu.FeesCollection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php if((generalSetting()->fees_status == 0 || !moduleStatusCheck('Fees')) && isMenuAllowToShow('fees')): ?>
                            <?php if(userPermission(108) && menuStatus(108)): ?>
                                <li data-position="<?php echo e(menuPosition(108)); ?>" class="sortable_li">
                                    <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                        <div class="nav_icon_small">
                                            <span class="flaticon-wallet"></span>
                                        </div>
                                        <div class="nav_title">
                                            <?php echo app('translator')->get('fees.fees_collection'); ?>
                                        </div>
                                    </a>
                                    <ul class="list-unstyled" id="subMenuFeesCollection">

                                        <?php if(!moduleStatusCheck('University') && directFees() == false): ?>
                                            <?php if(userPermission(123) && menuStatus(123)): ?>
                                                <li data-position="<?php echo e(menuPosition(123)); ?>">
                                                    <a href="<?php echo e(route('fees_group')); ?>"> <?php echo app('translator')->get('fees.fees_group'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if(userPermission(127) && menuStatus(127)): ?>
                                                <li data-position="<?php echo e(menuPosition(127)); ?>">
                                                    <a href="<?php echo e(route('fees_type')); ?>"> <?php echo app('translator')->get('fees.fees_type'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if(userPermission(131) && menuStatus(131)): ?>
                                            <li data-position="<?php echo e(menuPosition(131)); ?>">
                                                <a href="<?php echo e(route('fees-master')); ?>"> <?php echo app('translator')->get('fees.fees_master'); ?></a>
                                            </li>
                                        <?php endif; ?>


                                        <?php if(userPermission(118) && menuStatus(118)): ?>
                                            <li data-position="<?php echo e(menuPosition(118)); ?>">
                                                <a href="<?php echo e(route('fees_discount')); ?>"> <?php echo app('translator')->get('fees.fees_discount'); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if(userPermission(109) && menuStatus(109)): ?>
                                            <li data-position="<?php echo e(menuPosition(109)); ?>">
                                                <a href="<?php echo e(route('collect_fees')); ?>"> <?php echo app('translator')->get('fees.collect_fees'); ?></a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if(userPermission(113) && menuStatus(113)): ?>
                                            <li data-position="<?php echo e(menuPosition(113)); ?>">
                                                <a href="<?php echo e(route('search_fees_payment')); ?>">
                                                    <?php echo app('translator')->get('fees.search_fees_payment'); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if(userPermission(116) && menuStatus(116)): ?>
                                            <li data-position="<?php echo e(menuPosition(116)); ?>">
                                                <a href="<?php echo e(route('search_fees_due')); ?>">
                                                    <?php echo app('translator')->get('fees.search_fees_due'); ?></a>
                                            </li>
                                        <?php endif; ?>
                                                                            

                                        <?php if(!moduleStatusCheck('University') && directFees() == false): ?>
                                            <?php if(userPermission(136) && menuStatus(136)): ?>
                                                <li data-position="<?php echo e(menuPosition(136)); ?>">
                                                    <a href="<?php echo e(route('fees_forward')); ?>"> <?php echo app('translator')->get('fees.fees_forward'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if(userPermission(383) && menuStatus(383)): ?>
                                            <li data-position="<?php echo e(menuPosition(383)); ?>">
                                                <a
                                                        href="<?php echo e(route('transaction_report')); ?>"><?php echo app('translator')->get('fees.collection_report'); ?></a>
                                            </li>
                                        <?php endif; ?>


                                        
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(generalSetting()->fees_status == 1 && moduleStatusCheck('Fees') && isMenuAllowToShow('fees')): ?>
                        <?php if ($__env->exists('fees::sidebar.adminSidebar')) echo $__env->make('fees::sidebar.adminSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                     




                    
                    <?php if(userPermission(137) && menuStatus(137) && isMenuAllowToShow('accounts')): ?>
                        <li data-position="<?php echo e(menuPosition(137)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-accounting"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('accounts.accounts'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuAccount">
                                <?php if(userPermission(148) && menuStatus(148)): ?>
                                    <li data-position="<?php echo e(menuPosition(148)); ?>">
                                        <a href="<?php echo e(route('chart-of-account')); ?>">
                                            <?php echo app('translator')->get('accounts.chart_of_account'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(156) && menuStatus(156)): ?>
                                    <li data-position="<?php echo e(menuPosition(156)); ?>">
                                        <a href="<?php echo e(route('bank-account')); ?>"> <?php echo app('translator')->get('accounts.bank_account'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(139) && menuStatus(139)): ?>
                                    <li data-position="<?php echo e(menuPosition(139)); ?>">
                                        <a href="<?php echo e(route('add_income')); ?>"> <?php echo app('translator')->get('accounts.income'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(138) && menuStatus(138)): ?>
                                    <li data-position="<?php echo e(menuPosition(138)); ?>">
                                        <a href="<?php echo e(route('profit')); ?>"> <?php echo app('translator')->get('accounts.profit_&_loss'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(143) && menuStatus(143)): ?>
                                    <li data-position="<?php echo e(menuPosition(143)); ?>">
                                        <a href="<?php echo e(route('add-expense')); ?>"> <?php echo app('translator')->get('accounts.expense'); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if(userPermission(704) && menuStatus(704)): ?>
                                    <li data-position="<?php echo e(menuPosition(704)); ?>">
                                        <a href="<?php echo e(route('fund-transfer')); ?>"><?php echo app('translator')->get('accounts.fund_transfer'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(700) && menuStatus(700)): ?>
                                    <?php
                                        $subMenuAccountReport = ['fine-report', 'accounts-payroll-report', 'transaction'];
                                        $subMenuAccount = array_merge(['lead.index'], $subMenuAccountReport);
                                    ?>
                                    <li data-position="<?php echo e(menuPosition(700)); ?>">
                                        <a href="javascript:void(0)"
                                           class="has-arrow <?php echo e(spn_nav_item_open($subMenuAccount, 'active')); ?>"
                                           aria-expanded="false">
                                            <?php echo app('translator')->get('reports.report'); ?>
                                        </a>
                                        <ul class="list-unstyled <?php echo e(spn_nav_item_open($subMenuAccount, 'show')); ?>"
                                            id="subMenuAccountReport">
                                            <?php if(generalSetting()->fees_status == 0 && userPermission(701) && menuStatus(701)): ?>
                                                <li>
                                                    <a href="<?php echo e(route('fine-report')); ?>">
                                                        <?php echo app('translator')->get('accounts.fine_report'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if(userPermission(702) && menuStatus(702)): ?>
                                                <li>
                                                    <a href="<?php echo e(route('accounts-payroll-report')); ?>">
                                                        <?php echo app('translator')->get('accounts.payroll_report'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if(userPermission(703) && menuStatus(703)): ?>
                                                <li>
                                                    <a href="<?php echo e(route('transaction')); ?>">
                                                        <?php echo app('translator')->get('accounts.transaction'); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    <?php if(userPermission(160) && menuStatus(160) && isMenuAllowToShow('human_resource')): ?>
                        <li data-position="<?php echo e(menuPosition(160)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-consultation"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('hr.human_resource'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuHumanResource">
                                <?php if(userPermission(180) && menuStatus(180)): ?>
                                    <li data-position="<?php echo e(menuPosition(180)); ?>">
                                        <a href="<?php echo e(route('designation')); ?>"> <?php echo app('translator')->get('hr.designation'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(184) && menuStatus(184)): ?>
                                    <li data-position="<?php echo e(menuPosition(184)); ?>">
                                        <a href="<?php echo e(route('department')); ?>"> <?php echo app('translator')->get('hr.department'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(162) && menuStatus(162)): ?>
                                    <li data-position="<?php echo e(menuPosition(162)); ?>">
                                        <a href="<?php echo e(route('addStaff')); ?>"> <?php echo app('translator')->get('common.add_staff'); ?> </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(161) && menuStatus(161)): ?>
                                    <li data-position="<?php echo e(menuPosition(161)); ?>">
                                        <a href="<?php echo e(route('staff_directory')); ?>"> <?php echo app('translator')->get('hr.staff_directory'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(165) && menuStatus(162)): ?>
                                    <li data-position="<?php echo e(menuPosition(165)); ?>">
                                        <a href="<?php echo e(route('staff_attendance')); ?>"> <?php echo app('translator')->get('hr.staff_attendance'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(169) && menuStatus(169)): ?>
                                    <li data-position="<?php echo e(menuPosition(169)); ?>">
                                        <a href="<?php echo e(route('staff_attendance_report')); ?>">
                                            <?php echo app('translator')->get('hr.staff_attendance_report'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(170) && menuStatus(170)): ?>
                                    <li data-position="<?php echo e(menuPosition(170)); ?>">
                                        <a href="<?php echo e(route('payroll')); ?>"> <?php echo app('translator')->get('hr.payroll'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(178) && menuStatus(178)): ?>
                                    <li data-position="<?php echo e(menuPosition(178)); ?>">
                                        <a href="<?php echo e(route('payroll-report')); ?>"> <?php echo app('translator')->get('hr.payroll_report'); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(userPermission(952) && menuStatus(952)): ?>
                                    <li data-position="<?php echo e(menuPosition(951)); ?>">
                                        <a href="<?php echo e(route('staff_settings')); ?>"><?php echo app('translator')->get('student.settings'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                  
                    

                    <?php if(moduleStatusCheck('Chat') == true && isMenuAllowToShow('chat')): ?>
                        <?php echo $__env->make('chat::menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>      
            
                
            
                    
                    <?php if(userPermission(286) && menuStatus(286) && isMenuAllowToShow('communicate')): ?>
                        <li data-position="<?php echo e(menuPosition(286)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-email"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('communicate.communicate'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuCommunicate">
                                <?php if(userPermission(287) && menuStatus(287)): ?>
                                    <li data-position="<?php echo e(menuPosition(287)); ?>">
                                        <a href="<?php echo e(route('notice-list')); ?>"><?php echo app('translator')->get('communicate.notice_board'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(moduleStatusCheck('Saas') == true && Auth::user()->is_administrator != 'yes'): ?>
                                    <li>
                                        <a href="<?php echo e(route('administrator-notice')); ?>"><?php echo app('translator')->get('communicate.administrator_notice'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(291) && menuStatus(291)): ?>
                                    <li data-position="<?php echo e(menuPosition(291)); ?>">
                                        <a href="<?php echo e(route('send-email-sms-view')); ?>"><?php echo app('translator')->get('communicate.send_email_\/_sms'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(293) && menuStatus(293)): ?>
                                    <li data-position="<?php echo e(menuPosition(293)); ?>">
                                        <a href="<?php echo e(route('email-sms-log')); ?>"><?php echo app('translator')->get('communicate.email_sms_log'); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                
                                <?php if(userPermission(710) && menuStatus(710)): ?>
                                    <li data-position="<?php echo e(menuPosition(710)); ?>">
                                        <a
                                                href="<?php echo e(route('templatesettings.sms-template')); ?>"><?php echo app('translator')->get('communicate.sms_template'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(480) && menuStatus(480)): ?>
                                    <li data-position="<?php echo e(menuPosition(480)); ?>">
                                        <a href="<?php echo e(route('templatesettings.email-template')); ?>">
                                            <?php echo app('translator')->get('communicate.email_template'); ?>
                                        </a>
                                    </li>
                                    
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                   

                    
                    <?php if(userPermission(315) && menuStatus(315) && isMenuAllowToShow('inventory')): ?>
                        <li data-position="<?php echo e(menuPosition(315)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-inventory"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('inventory.inventory'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuInventory">
                                <?php if(userPermission(316) && menuStatus(316)): ?>
                                    <li data-position="<?php echo e(menuPosition(316)); ?>">
                                        <a href="<?php echo e(route('item-category')); ?>"> <?php echo app('translator')->get('inventory.item_category'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(320) && menuStatus(320)): ?>
                                    <li data-position="<?php echo e(menuPosition(320)); ?>">
                                        <a href="<?php echo e(route('item-list')); ?>"> <?php echo app('translator')->get('inventory.item_list'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(324) && menuStatus(324)): ?>
                                    <li data-position="<?php echo e(menuPosition(324)); ?>">
                                        <a href="<?php echo e(route('item-store')); ?>"> <?php echo app('translator')->get('inventory.item_store'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(328) && menuStatus(328)): ?>
                                    <li data-position="<?php echo e(menuPosition(328)); ?>">
                                        <a href="<?php echo e(route('suppliers')); ?>"> <?php echo app('translator')->get('inventory.supplier'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(332) && menuStatus(332)): ?>
                                    <li data-position="<?php echo e(menuPosition(332)); ?>">
                                        <a href="<?php echo e(route('item-receive')); ?>"> <?php echo app('translator')->get('inventory.item_receive'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(334) && menuStatus(334)): ?>
                                    <li data-position="<?php echo e(menuPosition(334)); ?>">
                                        <a href="<?php echo e(route('item-receive-list')); ?>">
                                            <?php echo app('translator')->get('inventory.item_receive_list'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(339) && menuStatus(339)): ?>
                                    <li data-position="<?php echo e(menuPosition(339)); ?>">
                                        <a href="<?php echo e(route('item-sell-list')); ?>"> <?php echo app('translator')->get('inventory.item_sell'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(345) && menuStatus(345)): ?>
                                    <li data-position="<?php echo e(menuPosition(345)); ?>">
                                        <a href="<?php echo e(route('item-issue')); ?>"> <?php echo app('translator')->get('inventory.item_issue'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

           
                     
                    
                    <?php if(userPermission(376) && menuStatus(376) && isMenuAllowToShow('reports')): ?>
                        <li data-position="<?php echo e(menuPosition(376)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-analysis"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('reports.reports'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenusystemReports">
                                <?php if(userPermission(538) && menuStatus(538)): ?>
                                    <li data-position="<?php echo e(menuPosition(538)); ?>">
                                        <a href="<?php echo e(route('student_report')); ?>"><?php echo app('translator')->get('reports.student_report'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(377) && menuStatus(377)): ?>
                                    <li data-position="<?php echo e(menuPosition(377)); ?>">
                                        <a href="<?php echo e(route('guardian_report')); ?>"><?php echo app('translator')->get('reports.guardian_report'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(378) && menuStatus(378)): ?>
                                    <li data-position="<?php echo e(menuPosition(378)); ?>">
                                        <a href="<?php echo e(route('student_history')); ?>"><?php echo app('translator')->get('reports.student_history'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(379) && menuStatus(379)): ?>
                                    <li data-position="<?php echo e(menuPosition(379)); ?>">
                                        <a href="<?php echo e(route('student_login_report')); ?>"><?php echo app('translator')->get('reports.student_login_report'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(generalSetting()->fees_status == 0): ?>
                                    <?php if(userPermission(381) && menuStatus(381)): ?>
                                        <li data-position="<?php echo e(menuPosition(381)); ?>">
                                            <a href="<?php echo e(route('fees_statement')); ?>"><?php echo app('translator')->get('reports.fees_statement'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(userPermission(382) && menuStatus(382)): ?>
                                        <li data-position="<?php echo e(menuPosition(382)); ?>">
                                            <a href="<?php echo e(route('balance_fees_report')); ?>"><?php echo app('translator')->get('reports.balance_fees_report'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if(!moduleStatusCheck('University')): ?>
                                    <?php if(userPermission(384) && menuStatus(384)): ?>
                                        <li data-position="<?php echo e(menuPosition(384)); ?>">
                                            <a href="<?php echo e(route('class_report')); ?>"><?php echo app('translator')->get('reports.class_report'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                               
                             


                          

                                
                                
                                
                                <?php if(userPermission(394) && menuStatus(394)): ?>
                                    <li data-position="<?php echo e(menuPosition(394)); ?>">
                                        <a href="<?php echo e(route('user_log')); ?>"><?php echo app('translator')->get('reports.user_log'); ?></a>
                                    </li>
                                <?php endif; ?>
                              
                                
                                <?php if(Auth::user()->role_id == 1): ?>
                                    <?php if(moduleStatusCheck('ResultReports') == true): ?>
                                        
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/cumulative-sheet-report')); ?>"><?php echo app('translator')->get('reports.cumulative_sheet_report'); ?></a>
                                        </li>
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/continuous-assessment-report')); ?>"><?php echo app('translator')->get('lang.contonuous_assessment_report'); ?></a>
                                        </li>
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/termly-academic-report')); ?>"><?php echo app('translator')->get('lang.termly_academic_report'); ?></a>
                                        </li>
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/academic-performance-report')); ?>"><?php echo app('translator')->get('lang.academic_performance_report'); ?></a>
                                        </li>
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/terminal-report-sheet')); ?>"><?php echo app('translator')->get('lang.terminal_report_sheet'); ?></a>
                                        </li>
                                        <li>
                                            <a
                                                    href="<?php echo e(route('resultreports/continuous-assessment-sheet')); ?>"><?php echo app('translator')->get('lang.continuous_assessment_sheet'); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('resultreports/result-version-two')); ?>"><?php echo app('translator')->get('lang.result_version'); ?>
                                                V2</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('resultreports/result-version-three')); ?>"><?php echo app('translator')->get('lang.result_version'); ?>
                                                V3
                                            </a>
                                        </li>
                                        
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(userPermission(417) && menuStatus(417) && isMenuAllowToShow('role_permission')): ?>
                        <li data-position="<?php echo e(menuPosition(417)); ?>" class="sortable_li">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-authentication"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('rolepermission::role.role_&_permission'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenuUserManagement">
                             
                                <?php if(userPermission(421) && menuStatus(421)): ?>
                                    <li data-position="<?php echo e(menuPosition(421)); ?>">
                                        <a href="<?php echo e(route('login-access-control')); ?>"><?php echo app('translator')->get('rolepermission::role.login_permission'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(userPermission(398) && menuStatus(398) && isMenuAllowToShow('system_settings')): ?>
                        <li data-position="<?php echo e(menuPosition(398)); ?>" class="sortable_li metis_submenu_up_collaspe">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-settings"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('system_settings.system_settings'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenusystemSettings">

                                <?php if(moduleStatusCheck('Saas') == true && auth()->user()->is_administrator == 'yes'): ?>
                                    <?php if(userPermission(405) && menuStatus(405)): ?>
                                        <li data-position="<?php echo e(menuPosition(405)); ?>">
                                            <a href="<?php echo e(route('school-general-settings')); ?>">
                                                <?php echo app('translator')->get('system_settings.general_settings'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if(userPermission(405) && menuStatus(405)): ?>
                                        <li data-position="<?php echo e(menuPosition(405)); ?>">
                                            <a href="<?php echo e(route('general-settings')); ?>">
                                                <?php echo app('translator')->get('system_settings.general_settings'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                

                                

                               

                               
 

                        
 
 

                                <?php if(userPermission(412) && menuStatus(412)): ?>
                                    <li data-position="<?php echo e(menuPosition(412)); ?>">
                                        <a href="<?php echo e(route('payment-method-settings')); ?>"><?php echo app('translator')->get('system_settings.payment_settings'); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(userPermission(410) && menuStatus(410)): ?>
                                    <li data-position="<?php echo e(menuPosition(410)); ?>">
                                        <a href="<?php echo e(route('email-settings')); ?>"><?php echo app('translator')->get('system_settings.email_settings'); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(userPermission(444) && menuStatus(444)): ?>
                                    <li data-position="<?php echo e(menuPosition(444)); ?>">
                                        <a href="<?php echo e(route('sms-settings')); ?>"><?php echo app('translator')->get('system_settings.sms_settings'); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                

                                
                                <?php if(moduleStatusCheck('Saas') == false): ?>
                                    <?php echo $__env->make('backEnd.partials.without_saas_school_admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <?php if(userPermission(2200) && menuStatus(2200)): ?>
                                    <li data-position="<?php echo e(menuPosition(2200)); ?>">
                                        <a href="<?php echo e(route('setting.preloader')); ?>"><?php echo app('translator')->get('system_settings.Preloader Settings'); ?> </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    
                    <?php if(userPermission(485) && menuStatus(485) && isMenuAllowToShow('style')): ?>
                        <li data-position="<?php echo e(menuPosition(485)); ?>" class="sortable_li metis_submenu_up_collaspe">
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-consultation"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('style.style'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="subMenusystemStyle">
                                <?php if(userPermission(486) && menuStatus(486)): ?>
                                    <li data-position="<?php echo e(menuPosition(486)); ?>">
                                        <a href="<?php echo e(route('background-setting')); ?>"><?php echo app('translator')->get('style.background_settings'); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(userPermission(490) && menuStatus(490)): ?>
                                    <li data-position="<?php echo e(menuPosition(490)); ?>">
                                        <a href="<?php echo e(route('color-style')); ?>"><?php echo app('translator')->get('style.color_theme'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    

      

                    
                    <?php if(moduleStatusCheck('Saas') == true && Auth::user()->is_administrator != 'yes'): ?>
                        <li>
                            <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
                                <div class="nav_icon_small">
                                    <span class="flaticon-settings"></span>
                                </div>
                                <div class="nav_title">
                                    <?php echo app('translator')->get('saas::saas.ticket_system'); ?>
                                </div>
                            </a>
                            <ul class="list-unstyled" id="Ticket">
                                <?php if(SaasDomain() == 'school' || userPermission(1935)): ?>
                                <li>
                                    <a href="<?php echo e(route('school/ticket-unassign-list')); ?>"><?php echo app('translator')->get('saas::saas.un_assign_ticket_list'); ?></a>
                                </li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('school/ticket-view')); ?>"><?php echo app('translator')->get('saas::saas.ticket_list'); ?></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>

                   

                <?php endif; ?>

                <!-- Student Panel -->
                <?php if(Auth::user()->role_id == 2): ?>
                    <?php echo $__env->make('backEnd/partials/student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <!-- Parents Panel Menu -->
                <?php if(Auth::user()->role_id == 3): ?>
                    <?php echo $__env->make('backEnd/partials/parents_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
</nav>
<!-- sidebar part end -->
<?php /**PATH C:\xampp\htdocs\pcgdb\resources\views/backEnd/partials/sidebar.blade.php ENDPATH**/ ?>