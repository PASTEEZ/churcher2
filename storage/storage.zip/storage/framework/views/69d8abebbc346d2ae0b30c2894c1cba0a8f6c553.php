 





 

<?php if(userPermission(456) && menuStatus(465)): ?>

    <li data-position="<?php echo e(menuPosition(465)); ?>">
        <a href="<?php echo e(route('backup-settings')); ?>"><?php echo app('translator')->get('system_settings.backup_settings'); ?></a>
    </li>
<?php endif; ?>




 
<?php if(userPermission(4000) && menuStatus(4000)): ?>

    <li data-position="<?php echo e(menuPosition(4000)); ?>">
        <a href="<?php echo e(route('utility')); ?>"><?php echo app('translator')->get('system_settings.utilities'); ?></a>
    </li>
<?php endif; ?>

 


<?php /**PATH C:\xampp\htdocs\pcgdb\resources\views/backEnd/partials/without_saas_school_admin_menu.blade.php ENDPATH**/ ?>