
    <?php $__env->startSection('title'); ?>
    MEMBERSHIP REPORT
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
<input type="text" hidden value="<?php echo e(@$clas->class_name); ?>" id="cls">
<input type="text" hidden value="<?php echo e(@$clas->section_name->sectionName->section_name); ?>" id="sec">
<section class="sms-breadcrumb mb-40 up_breadcrumb white-box">
    <div class="container-fluid">
        <div class="row justify-content-between">
            <h1>MEMBERSHIP REPORT</h1>
            <div class="bc-pages">
                <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('common.dashboard'); ?></a>
                <a href="#"><?php echo app('translator')->get('reports.reports'); ?></a>
                <a href="#"><?php echo app('translator')->get('reports.guardian_report'); ?></a>
            </div>
        </div>
    </div>
</section>
<section class="admin-visitor-area up_admin_visitor">
    <div class="container-fluid p-0">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="main-title">
                        <h3 class="mb-30"></h3>
                    </div>
                </div>
            </div>
            <?php echo e(Form::open(['class' => 'form-horizontal', 'files' => true, 'route' => 'membershiptype_report_search', 'method' => 'POST', 'enctype' => 'multipart/form-data'])); ?>

            <div class="row">
                <div class="col-lg-12">
                <div class="white-box">
                    <div class="row">
                                <input type="hidden" name="url" id="url" value="<?php echo e(URL::to('/')); ?>">
                               
                                <div class="col-lg-6 mt-30-md">
                                    <select class="niceSelect w-100 bb form-control <?php echo e($errors->has('class') ? ' is-invalid' : ''); ?>" id="select_class" name="class">
                                        <option data-display="<?php echo app('translator')->get('common.select_class'); ?>*" value=""><?php echo app('translator')->get('common.select_class'); ?> *</option>
                                        <?php $__currentLoopData = $memberstypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberstype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($memberstype->id); ?>" > <?php echo e($memberstype->membertype_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('class')): ?>
                                    <span class="invalid-feedback invalid-select" role="alert">
                                        <strong><?php echo e($errors->first('class')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                 

 

                                <div class="col-lg-6 mt-30-md" id="select_section_div">
                                    <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('section') ? ' is-invalid' : ''); ?>" id="select_section" name="section">
                                        <option data-display="<?php echo app('translator')->get('common.select_section'); ?>" value=""><?php echo app('translator')->get('common.select_section'); ?></option>
                                        <?php if(isset($class_id)): ?>
                                            <?php $__currentLoopData = $gender->classSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gender->sectionName->id); ?>" <?php echo e(old('section')==$gender->sectionName->id ? 'selected' : ''); ?> >
                                                <?php echo e($gender->gender_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </select>
                                    <div class="pull-right loader loader_style" id="select_section_loader">
                                        <img class="loader_img_style" src="<?php echo e(asset('public/backEnd/img/demo_wait.gif')); ?>" alt="loader">
                                    </div>
                                     
                                </div>



                                
                                <div class="col-lg-12 mt-20 text-right">
                                    <button type="submit" class="primary-btn small fix-gr-bg">
                                        <span class="ti-search pr-2"></span>
                                        <?php echo app('translator')->get('common.search'); ?>
                                    </button>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

            <?php if(isset($student_records)): ?>
            <div class="row mt-40"> 
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-4 no-gutters">
                            <div class="main-title">
                                <h3 class="mb-0"><?php echo app('translator')->get('reports.guardian_report'); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table id="table_ids" class="display school-table" cellspacing="0" width="100%">
                                <thead>
                                   
                                    <tr>
                                         
                                        <th><?php echo app('translator')->get('common.class'); ?></th>
                                        <th><?php echo app('translator')->get('common.section'); ?></th>
 

                                        <th><?php echo app('translator')->get('student.admission_no'); ?></th>
                                        <th><?php echo app('translator')->get('common.name'); ?></th>
                                        <th><?php echo app('translator')->get('common.mobile'); ?></th>
                                        <th><?php echo app('translator')->get('student.guardian_name'); ?></th>
                                        <th><?php echo app('translator')->get('reports.relation_with_guardian'); ?></th>
                                        <th><?php echo app('translator')->get('student.guardian_phone'); ?> </th>
                                        <th><?php echo app('translator')->get('student.father_name'); ?> </th>
                                        <th><?php echo app('translator')->get('student.father_phone'); ?> </th>
                                        <th><?php echo app('translator')->get('student.mother_name'); ?> </th>
                                        <th><?php echo app('translator')->get('student.mother_phone'); ?> </th>
                                    </tr>
                                </thead>

                                <tbody>
                                 
                                    <?php $__currentLoopData = $student_records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                
                                        <td><?php echo e(@$record->class->class_name); ?></td>
                                        <td> <?php echo e(@$record->section->section_name); ?></td>
                                       
                                        <td><?php echo e(@$record->student->admission_no); ?></td>
                                        <td><?php echo e(@$record->student->full_name); ?></td>
                                        <td><?php echo e(@$record->student->mobile); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->guardians_name:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->guardians_relation:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->guardians_mobile:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->fathers_name:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->fathers_mobile:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->mothers_name:""); ?></td>
                                        <td><?php echo e(@$record->student->parents!=""?@$record->student->parents->mothers_mobile:""); ?></td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\churcher\resources\views/backEnd/studentInformation/membershiptype_report.blade.php ENDPATH**/ ?>