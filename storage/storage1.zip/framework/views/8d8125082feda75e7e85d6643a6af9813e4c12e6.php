
<?php if(userPermission(1130) && menuStatus(1130)): ?>
    <li data-position="<?php echo e(menuPosition(1130)); ?>" class="sortable_li">
        <a href="javascript:void(0)" class="has-arrow" aria-expanded="false">
            <div class="nav_icon_small">
                <span class="flaticon-test"></span>
            </div>
            <div class="nav_title">
                <?php echo app('translator')->get('fees.fees'); ?>
            </div>
        </a>
        <ul class="list-unstyled" id="subMenuFees">
            <?php if(userPermission(1131) && menuStatus(1131)): ?>
                <li data-position="<?php echo e(menuPosition(1131)); ?>">
                    <a href="<?php echo e(route('fees.fees-group')); ?>"><?php echo app('translator')->get('fees.fees_group'); ?></a>
                </li>
            <?php endif; ?>

            <?php if(userPermission(1135) && menuStatus(1135)): ?>
                <li data-position="<?php echo e(menuPosition(1135)); ?>">
                    <a href="<?php echo e(route('fees.fees-type')); ?>"><?php echo app('translator')->get('fees.fees_type'); ?></a>
                </li>
            <?php endif; ?>

            <?php if(userPermission(1139) && menuStatus(1139)): ?>
                <li data-position="<?php echo e(menuPosition(1139)); ?>">
                    <a href="<?php echo e(route('fees.fees-invoice-list')); ?>"><?php echo app('translator')->get('fees::feesModule.fees_invoice'); ?></a>
                </li>
            <?php endif; ?>

          
   
                    <?php if(userPermission(1159) && menuStatus(1159)): ?>
                        <li data-position="<?php echo e(menuPosition(1159)); ?>">
                            <a href="<?php echo e(route('fees.payment-report')); ?>">
                                <?php echo app('translator')->get('fees::feesModule.payment_report'); ?>
                            </a>
                        </li>
                    <?php endif; ?>

           
        </ul>
    </li>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\churcher\Modules/Fees\Resources/views/sidebar/adminSidebar.blade.php ENDPATH**/ ?>