    <?php $__env->startSection('title'); ?> 
        <?php echo app('translator')->get('fees::feesModule.balance_report'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>

<section class="sms-breadcrumb mb-40 white-box">
    <div class="container-fluid">
        <div class="row justify-content-between">
            <h1><?php echo app('translator')->get('fees::feesModule.balance_report'); ?></h1>
            <div class="bc-pages">
                <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('common.dashboard'); ?></a>
                <a href="#"><?php echo app('translator')->get('fees::feesModule.fees'); ?></a>
                <a href="#"><?php echo app('translator')->get('fees::feesModule.report'); ?></a>
                <a href="#"><?php echo app('translator')->get('fees::feesModule.balance_report'); ?></a>
            </div>
        </div>
    </div>
</section>

<section class="admin-visitor-area">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="main-title">
                    <h3 class="mb-30"><?php echo app('translator')->get('common.select_criteria'); ?> </h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="white-box">
                    <?php echo e(Form::open(['class' => 'form-horizontal', 'route' => 'fees.balance-search', 'method' => 'POST'])); ?>

                        <?php echo $__env->make('fees::report._searchForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
        <?php if(isset($fees_dues)): ?>
            <div class="row mt-40">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-12 search_hide_md">
                            <table id="table_id" class="display school-table fees-report-footer" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th><?php echo app('translator')->get('common.sl'); ?></th>
                                        <th><?php echo app('translator')->get('student.admission_no'); ?></th>
                                        <th><?php echo app('translator')->get('student.roll_no'); ?></th>
                                        <th><?php echo app('translator')->get('common.name'); ?></th>
                                        <th><?php echo app('translator')->get('fees::feesModule.due_date'); ?></th>
                                        <th><?php echo app('translator')->get('fees::feesModule.balance'); ?> (<?php echo e(generalSetting()->currency_symbol); ?>)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $totalBalance = 0;
                                    ?>
                                    <?php $__currentLoopData = $fees_dues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$fees_due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $fine = $fees_due->Tfine;
                                            $paid_amount = $fees_due->Tpaidamount;
                                            $sub_total = $fees_due->Tsubtotal;
                                            $balance = $sub_total - $paid_amount + $fine;
                                            $totalBalance += $balance;
                                        ?>
                                            <?php if($balance != 0): ?>
                                                <tr>
                                                    <td><?php echo e($key+1); ?></td>
                                                    <td><?php echo e(@$fees_due->studentInfo->admission_no); ?></td>
                                                    <td><?php echo e(@$fees_due->recordDetail->roll_no); ?></td>
                                                    <td><?php echo e(@$fees_due->studentInfo->full_name); ?></td>
                                                    <td><?php echo e(dateConvert($fees_due->due_date)); ?></td>
                                                    <td><?php echo e($balance); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td class="text-right"><?php echo app('translator')->get('dashboard.total'); ?></td>
                                        <td><?php echo e($totalBalance); ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div> 
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="<?php echo e(url('Modules\Fees\Resources\assets\js\app.js')); ?>"></script>
    <script>
        $('input[name="date_range"]').daterangepicker({
            ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            "startDate": moment().subtract(7, 'days'),
            "endDate": moment()
            }, function(start, end, label) {
            console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\churcher\Modules/Fees\Resources/views/report/balance.blade.php ENDPATH**/ ?>