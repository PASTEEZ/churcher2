
    <?php $__env->startSection('title'); ?> 
        <?php if(isset($invoiceInfo)): ?>
            <?php echo app('translator')->get('common.edit'); ?>
        <?php else: ?>
            <?php echo app('translator')->get('common.add'); ?>
        <?php endif; ?> 
            <?php echo app('translator')->get('fees.fees_invoice'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(url('Modules\Fees\Resources\assets\css\feesStyle.css')); ?>"/>
    <?php $__env->stopPush(); ?>
    <section class="sms-breadcrumb mb-40 white-box">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <h1><?php if(isset($invoiceInfo)): ?>
                    <?php echo app('translator')->get('common.edit'); ?>
                <?php else: ?>
                    <?php echo app('translator')->get('common.add'); ?>
                <?php endif; ?> 
                    <?php echo app('translator')->get('fees.fees_invoice'); ?></h1>
                <div class="bc-pages">
                    <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('common.dashboard'); ?></a>
                    <a href="#"><?php echo app('translator')->get('fees.fees'); ?></a>
                    <a href="<?php echo e(route('fees.fees-invoice-list')); ?>"><?php echo app('translator')->get('fees.fees_invoice'); ?></a>
                    <a href="#">
                        <?php if(isset($invoiceInfo)): ?>
                            <?php echo app('translator')->get('common.edit'); ?>
                        <?php else: ?>
                            <?php echo app('translator')->get('common.add'); ?>
                        <?php endif; ?>
                            <?php echo app('translator')->get('fees.fees_invoice'); ?></a>
                </div>
            </div>
        </div>
    </section>
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">

            
            <?php if(isset($invoiceInfo)): ?>
                <?php echo e(Form::open(['class' => 'form-horizontal', 'method' => 'POST', 'route' => 'fees.fees-invoice-update'])); ?>

                <input type="hidden" name="id" class="editValue" value="<?php echo e($invoiceInfo->id); ?>">
            <?php else: ?>
                <?php echo e(Form::open(['class' => 'form-horizontal', 'method' => 'POST', 'route' => 'fees.fees-invoice-store'])); ?>

            <?php endif; ?>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="main-title">
                                    <h3 class="mb-30">
                                        <?php if(isset($invoiceInfo)): ?>
                                            <?php echo app('translator')->get('common.edit'); ?>
                                        <?php else: ?>
                                            <?php echo app('translator')->get('common.add'); ?>
                                        <?php endif; ?>
                                            <?php echo app('translator')->get('fees.fees_invoice'); ?>
                                    </h3>
                                </div>
                                    <input type="hidden" name="url" id="url" value="<?php echo e(URL::to('/')); ?>">
                                <div class="white-box">
                                    <div class="add-visitor">                              
                                        

                                    <?php if(moduleStatusCheck('University')): ?>
                                        <?php if ($__env->exists('university::common.session_faculty_depart_academic_semester_level',
                                        ['required' => 
                                            ['USN', 'UD', 'UA', 'US', 'USL','USEC'],'hide'=> ['USUB'],
                                            'div'=>'col-lg-12','row'=>1,
                                             'mt'=>'mt-0','disabled'=>true
                                        ])) echo $__env->make('university::common.session_faculty_depart_academic_semester_level',
                                        ['required' => 
                                            ['USN', 'UD', 'UA', 'US', 'USL','USEC'],'hide'=> ['USUB'],
                                            'div'=>'col-lg-12','row'=>1,
                                             'mt'=>'mt-0','disabled'=>true
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                                        <div class="row">
                                            <div class="col-lg-12 mt-30" id="select_un_student_div">
                                                <?php echo e(Form::select('student_id', @$students ?? [""=>__('common.select_student').'*'], $invoiceInfo ? $invoiceInfo->student_id : null , ['class' => 'niceSelect w-100 bb form-control'. ($errors->has('student_id') ? ' is-invalid' : ''), 'id'=>'select_un_student',  isset($invoiceInfo) ? 'disabled' : ''])); ?>


                                                <span class="focus-border"></span>
                                                <div class="pull-right loader loader_style" id="select_un_student_loader">
                                                    <img class="loader_img_style" src="<?php echo e(asset('public/backEnd/img/demo_wait.gif')); ?>" alt="loader">
                                                </div>
                                                <?php if($errors->has('student_id')): ?>
                                                    <span class="invalid-feedback custom-error-message" role="alert">
                                                        <?php echo e(@$errors->first('student_id')); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                       

                                        <div class="row mt-25">
                                            <div class="col-lg-12" id="">
                                                <select class="w-100 bb niceSelect form-control<?php echo e($errors->has('student') ? ' is-invalid' : ''); ?>" id="selectStudent" name="student">
                                                <option data-display="<?php echo app('translator')->get('common.select_student'); ?> *" value=""><?php echo app('translator')->get('common.select_student'); ?>*</option>
                                               
                                                <?php dump($students); ?>
                                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->full_name); ?> (  - <?php echo e($student->roll_no); ?>)</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         
                                            </select>
                                            <div class="pull-right loader" id="selectStudentLoader" style="margin-top: -30px;padding-right: 21px;">
                                                <img src="<?php echo e(asset('Modules/Fees/Resources/assets/img/pre-loader.gif')); ?>" alt="" style="width: 28px;height:28px;">
                                            </div>
                                            <?php if($errors->has('student')): ?>
                                                <span class="invalid-feedback invalid-select" role="alert">
                                                    <strong><?php echo e($errors->first('student')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                        <div class="row no-gutters input-right-icon mt-30">
                                            <div class="col">
                                                <div class="input-effect">
                                                    <input class="primary-input date form-control<?php echo e($errors->has('create_date') ? ' is-invalid' : ''); ?>" id="startDate" type="text" name="create_date" value="<?php echo e(isset($invoiceInfo)? date('m/d/Y', strtotime($invoiceInfo->create_date)) : date('m/d/Y')); ?>">
                                                        <label><?php echo app('translator')->get('fees.create_date'); ?> <span>*</span></label>
                                                    <span class="focus-border"></span>
                                                    <?php if($errors->has('create_date')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('create_date')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <button class="" type="button">
                                                    <i class="ti-calendar" id="start-date-icon"></i>
                                                </button>
                                            </div>
                                        </div>

                                        <div class="row no-gutters input-right-icon mt-30">
                                            <div class="col">
                                                <div class="input-effect">
                                                    <input class="primary-input date form-control<?php echo e($errors->has('due_date') ? ' is-invalid' : ''); ?>" id="startDate" type="text" name="due_date" value="<?php echo e(isset($invoiceInfo)? date('m/d/Y', strtotime($invoiceInfo->due_date)) : date('m/d/Y')); ?>">
                                                        <label><?php echo app('translator')->get('fees.due_date'); ?> <span>*</span></label>
                                                    <span class="focus-border"></span>
                                                    <?php if($errors->has('due_date')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('due_date')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <button class="" type="button">
                                                    <i class="ti-calendar" id="start-date-icon"></i>
                                                </button>
                                            </div>
                                        </div>

                                        <div class="row mt-25">
                                            <div class="col-lg-12">
                                                <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('payment_status') ? ' is-invalid' : ''); ?>" name="payment_status" id="paymentStatus">
                                                 
                                                    
                                                   
                                                    <option value="full" <?php echo e(isset($invoiceInfo)? ($invoiceInfo->payment_status == "full"?'selected':''):(old('payment_status') == 'full' ? 'selected' : '')); ?>><?php echo app('translator')->get('fees.paid'); ?></option>
                                                </select>
                                                <?php if($errors->has('payment_status')): ?>
                                                    <span class="invalid-feedback invalid-select" role="alert">
                                                        <strong><?php echo e($errors->first('payment_status')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="row mt-25 d-none" id="paymentMethod">
                                            <div class="col-lg-12">
                                                <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('payment_method') ? ' is-invalid' : ''); ?>" name="payment_method" id="paymentMethodName">
                                                     
                                                    <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($paymentMethod->method); ?>" <?php echo e(isset($invoiceInfo)? ($invoiceInfo->payment_method == $paymentMethod->method?'selected':''):(old('payment_method') == $paymentMethod->method ? 'selected' : '')); ?>><?php echo e($paymentMethod->method); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            
                                            </div>
                                        </div>

                                         
                                        
                                        <?php 
                                        $tooltip = "";
                                        if(userPermission(119)){
                                                $tooltip = "";
                                            }else{
                                                $tooltip = "You have no permission to add";
                                            }
                                        ?>

                                        <div class="row mt-40">
                                            <div class="col-lg-12 text-center">
                                                <button class="primary-btn fix-gr-bg submit fmInvoice" data-tooltip="tooltip" title="<?php echo e($tooltip); ?>">
                                                    <span class="ti-check"></span>
                                                    <?php if(isset($invoiceInfo)): ?>
                                                        <?php echo app('translator')->get('common.update'); ?>
                                                    <?php else: ?>
                                                        <?php echo app('translator')->get('common.save'); ?>
                                                    <?php endif; ?>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-lg-4 no-gutters">
                                <div class="main-title">
                                    <h3 class="mb-0"><?php echo app('translator')->get('fees.fees_type_list'); ?></h3>
                                </div>
                            </div>
                        </div>


                        <div class="row mt-30">
                            <div class="col-lg-12">
                                <div class="white-box pb-0 fees_invoice_type_div">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <select class="niceSelect w-100 bb form-control<?php echo e($errors->has('fees_type') ? ' is-invalid' : ''); ?>" id="selectFeesType" name="fees_type">
                                                <option data-display="<?php echo app('translator')->get('fees.fees_type'); ?> *" value=""><?php echo app('translator')->get('fees.fees_type'); ?> *</option>
                                                <option value="" disabled><?php echo app('translator')->get('fees.fees_group'); ?></option>
                                                <?php $__currentLoopData = $feesGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feesGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="grp<?php echo e($feesGroup->id); ?>"><?php echo e($feesGroup->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <option value="" disabled><?php echo app('translator')->get('fees.fees_type'); ?></option>
                                                <?php $__currentLoopData = $feesTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feesType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="typ<?php echo e($feesType->id); ?>"><?php echo e($feesType->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('fees_type')): ?>
                                                <span class="invalid-feedback invalid-select" role="alert">
                                                    <strong><?php echo e($errors->first('fees_type')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                     
                                </div>
                                <input type="hidden" class="weaverType" value="amount">
                                <div class="big-table">
                                    <table class="display school-table school-table-style fees_invoice_type_table" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo app('translator')->get('common.sl'); ?></th>
                                                <th><?php echo app('translator')->get('fees.fees_type'); ?></th>
                                                <th><?php echo app('translator')->get('accounts.amount'); ?></th>
                                                 
                                                <th><?php echo app('translator')->get('fees.sub_total'); ?></th>
                                                <th><?php echo app('translator')->get('fees.paid_amount'); ?></th>
                                                <th><?php echo app('translator')->get('common.action'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody class="allFeesTypes">
                                            <?php if(isset($invoiceInfo)): ?>
                                                <?php $__currentLoopData = $invoiceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$invoiceDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td></td>
                                                        <td><?php echo e($invoiceDetail->feesType->name); ?></td>
                                                        <input type="hidden" name="feesType[]" value="<?php echo e($invoiceDetail->fees_type); ?>">
                                                        <td>
                                                            <div class="input-effect">
                                                                <input class="primary-input form-control amount<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" type="text" name="amount[]" autocomplete="off" value="<?php echo e(isset($invoiceDetail)? $invoiceDetail->amount: old('amount')); ?>">
                                                                <span class="focus-border"></span>
                                                                <?php if($errors->has('amount')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('amount')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </td>
                                                        
                                                        <td class="subTotal"><?php echo e(isset($invoiceDetail)? $invoiceDetail->sub_total: ""); ?></td>
                                                        <input type="hidden" name="sub_total[]" class="inputSubTotal" value="<?php echo e(isset($invoiceDetail)? $invoiceDetail->sub_total: ""); ?>">
                                                        <td>
                                                            <input class="primary-input form-control paidAmount<?php echo e($errors->has('paid_amount') ? ' is-invalid' : ''); ?>" type="text" name="paid_amount[]" autocomplete="off" disabled value="<?php echo e(isset($invoiceDetail)? $invoiceDetail->paid_amount: old('paid_amount')); ?>">
                                                        </td>
                                                        <td>
                                                            <button class="primary-btn icon-only fix-gr-bg" data-toggle="modal" data-tooltip="tooltip" data-target="#addNotesModal<?php echo e($invoiceDetail->fees_type); ?>" type="button"
                                                                title="<?php echo app('translator')->get('common.edit_note'); ?>">
                                                                <span class="ti-pencil-alt"></span>
                                                            </button>
                                                            <button class="primary-btn icon-only fix-gr-bg" type="button" data-tooltip="tooltip" title="<?php echo app('translator')->get('common.delete'); ?>" id="deleteField">
                                                                <span class="ti-trash"></span>
                                                            </button>
                                                            
                                                            <div class="modal fade admin-query" id="addNotesModal<?php echo e($invoiceDetail->fees_type); ?>">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h4 class="modal-title"><?php echo app('translator')->get('common.edit_note'); ?></h4>
                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                        </div>

                                                                        <div class="modal-body">
                                                                            <div class="input-effect">
                                                                                <input class="primary-input form-control has-content" type="text" name="note[]" autocomplete="off" value="<?php echo e(isset($invoiceDetail)? $invoiceDetail->note: ""); ?>">
                                                                                <label><?php echo app('translator')->get('common.note'); ?></label>
                                                                                <span class="focus-border"></span>
                                                                            </div>
                                                                            </br>
                                                                            <div class="mt-40 d-flex justify-content-between">
                                                                                <button type="button" class="primary-btn tr-bg" data-dismiss="modal"><?php echo app('translator')->get('common.cancel'); ?></button>
                                                                                <button type="button" class="primary-btn fix-gr-bg" data-dismiss="modal"><?php echo app('translator')->get('common.update'); ?></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <input type="hidden" class="fees" value="grp<?php echo e($invoiceDetail->feesType->fees_group_id); ?>">
                                                            <input type="hidden" class="fees" value="typ<?php echo e($invoiceDetail->fees_type); ?>">
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td><?php echo app('translator')->get('exam.result'); ?></td>
                                                <td></td>
                                                <td class="showTotalAmount">0.00</td>
                                                <td class="showTotalWeaver">0.00</td>
                                                <td class="showSubTotalDiscount">0.00</td>
                                                <td class="showPaidAmount">0.00</td>
                                                <td></td>
                                                <input class="totalPaidAmount" type="hidden" name="total_paid_amount">
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="<?php echo e(url('Modules\Fees\Resources\assets\js\app.js')); ?>"></script>
    <script>
        selectPosition(<?php echo feesInvoiceSettings()->invoice_positions; ?>);
    </script>
    <script>
        $(document).ready(function() {
            $("#select_semester_label").on("change", function() {

                var url = $("#url").val();
                var i = 0;
                let semester_id = $(this).val();
                let academic_id = $('#select_academic').val();  
                let session_id = $('#select_session').val();
                let faculty_id = $('#select_faculty').val();
                let department_id = $('#select_dept').val();
                let un_semester_label_id = $('#select_semester_label').val();

                if (session_id =='') {
                    setTimeout(function() {
                        toastr.error(
                        "Session Not Found",
                        "Error ",{
                            timeOut: 5000,
                    });}, 500);
                
                    $("#select_semester option:selected").prop("selected", false)
                    return ;
                }
                if (department_id =='') {
                    setTimeout(function() {
                        toastr.error(
                        "Department Not Found",
                        "Error ",{
                            timeOut: 5000,
                    });}, 500);
                    $("#select_semester option:selected").prop("selected", false)

                    return ;
                }
                if (semester_id =='') {
                    setTimeout(function() {
                        toastr.error(
                        "Semester Not Found",
                        "Error ",{
                            timeOut: 5000,
                    });}, 500);
                    $("#select_semester option:selected").prop("selected", false)

                    return ;
                }
                if (academic_id =='') {
                    setTimeout(function() {
                        toastr.error(
                        "Academic Not Found",
                        "Error ",{
                            timeOut: 5000,
                    });}, 500);
                    return ;
                }
                if (un_semester_label_id =='') {
                    setTimeout(function() {
                        toastr.error(
                        "Semester Label Not Found",
                        "Error ",{
                            timeOut: 5000,
                    });}, 500);
                    return ;
                }

                var formData = {
                    semester_id : semester_id,
                    academic_id : academic_id,
                    session_id : session_id,
                    faculty_id : faculty_id,
                    department_id : department_id,
                    un_semester_label_id : un_semester_label_id,
                };
            
                // Get Student
                $.ajax({
                    type: "GET",
                    data: formData,
                    dataType: "json",
                    url: url + "/university/" + "get-university-wise-student",
                    beforeSend: function() {
                        $('#select_un_student_loader').addClass('pre_loader').removeClass('loader');
                    },
                    success: function(data) {
                        var a = "";
                        $.each(data, function(i, item) {
                            if (item.length) {
                                $("#select_un_student").find("option").not(":first").remove();
                                $("#select_un_student_div ul").find("li").not(":first").remove();

                                $("#select_un_student").append(
                                    $("<option>", {
                                        value: 'all_student',
                                        text: "",
                                    })
                                );

                                $.each(item, function(i, students) {
                                    $("#select_un_student").append(
                                        $("<option>", {
                                            value: students.student.id,
                                            text: students.student.full_name,
                                        })
                                    );

                                    $("#select_un_student_div ul").append(
                                        "<li data-value='" +
                                        students.student.id +
                                        "' class='option'>" +
                                        students.student.full_name +
                                        "</li>"
                                    );
                                });
                                $("#select_un_student").niceSelect('update');
                            } else {
                                $("#select_un_student").find("option").not(":first").remove();
                                $("#select_un_student_div ul").find("li").not(":first").remove();
                            }
                        });
                    },
                    error: function(data) {
                        console.log("Error:", data);
                    },
                    complete: function() {
                        i--;
                        if (i <= 0) {
                            $('#select_un_student_loader').removeClass('pre_loader').addClass('loader');
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\churcher\Modules/Fees\Resources/views/feesInvoice/feesInvoice.blade.php ENDPATH**/ ?>