
    <?php $__env->startSection('title'); ?> 
        <?php echo app('translator')->get('fees::feesModule.fees_invoice_settings'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(url('Modules\Fees\Resources\assets\css\feesStyle.css')); ?>"/>
    <?php $__env->stopPush(); ?>
    <section class="sms-breadcrumb mb-40 white-box">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <h1><?php echo app('translator')->get('fees::feesModule.fees_invoice_settings'); ?></h1>
                <div class="bc-pages">
                    <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('common.dashboard'); ?></a>
                    <a href="#"><?php echo app('translator')->get('fees.fees'); ?></a>
                    <a href="#"><?php echo app('translator')->get('fees::feesModule.fees_invoice_settings'); ?></a>
                </div>
            </div>
        </div>
    </section>
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h3 class="mb-30">
                                    <?php echo app('translator')->get('fees::feesModule.invoice_number_generator'); ?>
                                </h3>
                            </div>
                            <?php
                                $invoicePostions = json_decode($invoiceSettings->invoice_positions);
                            ?>
                            <input type="hidden" name="url" id="url" value="<?php echo e(URL::to('/')); ?>">
                            <?php if(isset($invoiceSettings)): ?>
                                <input type="hidden" name="id" id="ID" value="<?php echo e($invoiceSettings->id); ?>">
                            <?php endif; ?>
                            <div class="white-box">
                                <div class="add-visitor">
                                    <div class="row no-gutters input-right-icon mt-20">
                                        <div class="col-lg-12">
                                            <label for="checkbox" class="mb-2"><?php echo app('translator')->get('fees::feesModule.invoice_number_position'); ?>*</label>
                                            <select ata-tags="true" multiple id="e1" name="invoice_positions[]" style="width:300px" class="selectValue">
                                                <option value="prefix"><?php echo app('translator')->get('fees::feesModule.prefix'); ?> </option>
                                                <option value="admission_no"><?php echo app('translator')->get('student.admission_no'); ?></option>
                                                <option value="class"><?php echo app('translator')->get('common.class'); ?></option>
                                                <option value="section"><?php echo app('translator')->get('common.section'); ?></option>
                                            </select>
                                            <?php if($errors->has('invoice_positions')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('invoice_positions')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                            <div class="">
                                                <input type="checkbox" id="checkbox" class="common-checkbox">
                                                <label for="checkbox" class="mt-3"><?php echo app('translator')->get('common.select_all'); ?> </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-lg-4 no-gutters">
                            <div class="main-title">
                                <h3 class="mb-0"><?php echo app('translator')->get('fees::feesModule.invoice_number_preview'); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-30">
                        <div class="col-lg-12">
                            <div class="white-box">
                                <div class="row fees_custom_preview" id="showValue">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col-lg-12">
                    <div class="main-title">
                        <h3 class="mb-30 mt-30">
                            <?php echo app('translator')->get('fees::feesModule.invoice_attribute'); ?>
                        </h3>
                    </div>
                    <table class="display school-table school-table-style" cellspacing="0" width="100%">
                        <tbody>
                            <tr>
                                <td>
                                    <div class="col-lg-12">
                                        <div class="input-effect">
                                            <input class="primary-input form-control<?php echo e($errors->has('uniq_id_start') ? ' is-invalid' : ''); ?>" type="text" name="uniq_id_start" id="uniq_id_start" autocomplete="off" value="<?php echo e(isset($invoiceSettings)? $invoiceSettings->uniq_id_start: old('uniq_id_start')); ?>">
                                            <label><?php echo app('translator')->get('fees::feesModule.uniq_id_start'); ?>*</label>
                                            <span class="focus-border"></span>
                                                <?php if($errors->has('uniq_id_start')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('uniq_id_start')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="col-lg-12">
                                        <div class="input-effect">
                                            <input class="primary-input form-control<?php echo e($errors->has('prefix') ? ' is-invalid' : ''); ?>" type="text" name="prefix" id="prefix" autocomplete="off" value="<?php echo e(isset($invoiceSettings)? $invoiceSettings->prefix: old('prefix')); ?>" maxlength="10">
                                            <label><?php echo app('translator')->get('fees::feesModule.prefix'); ?> (<?php echo app('translator')->get('fees::feesModule.max_10_characters'); ?>)</label>
                                            <span class="focus-border"></span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="col-lg-12">
                                        <div class="input-effect">
                                            <input class="primary-input form-control<?php echo e($errors->has('class_limit') ? ' is-invalid' : ''); ?>" type="text"  name="class_limit" id="class_limit" autocomplete="off" value="<?php echo e(isset($invoiceSettings)? $invoiceSettings->class_limit: old('class_limit')); ?>">
                                            <label><?php echo app('translator')->get('fees::feesModule.class_limit'); ?></label>
                                            <span class="focus-border"></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="col-lg-12">
                                        <div class="input-effect">
                                            <input class="primary-input form-control<?php echo e($errors->has('section_limit') ? ' is-invalid' : ''); ?>" type="text" name="section_limit" id="section_limit" autocomplete="off" value="<?php echo e(isset($invoiceSettings)? $invoiceSettings->section_limit: old('section_limit')); ?>">
                                            <label><?php echo app('translator')->get('fees::feesModule.section_limit'); ?></label>
                                            <span class="focus-border"></span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="col-lg-12">
                                        <div class="input-effect">
                                            <input class="primary-input form-control<?php echo e($errors->has('admission_limit') ? ' is-invalid' : ''); ?>" type="text" name="admission_limit" id="admission_limit" autocomplete="off" value="<?php echo e(isset($invoiceSettings)? $invoiceSettings->admission_limit: old('admission_limit')); ?>">
                                            <label><?php echo app('translator')->get('fees::feesModule.admission_no_limit'); ?></label>
                                            <span class="focus-border"></span>
                                        </div>
                                    </div>
                                </td>
                                
                            </tr>
                        </tbody>
                    </table>
                    <div class="row mt-40">
                        <div class="col-lg-12 text-center">
                            <?php if(userPermission(1153)): ?>
                                <button class="primary-btn fix-gr-bg submit" data-toggle="tooltip" id="invSetting">
                                    <span class="ti-check"></span>
                                    <?php echo app('translator')->get('common.update'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="<?php echo e(url('Modules\Fees\Resources\assets\js\app.js')); ?>"></script>
    <script>
        $('.selectValue').select2('data',<?php echo $invoiceSettings->invoice_positions; ?>);
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\churcher\Modules/Fees\Resources/views/feesInvoiceSettings.blade.php ENDPATH**/ ?>