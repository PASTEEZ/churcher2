<style>
    :root {
        --base_font : "<?php echo e(in_array(app()->getLocale(), ['ar']) ?  'Tajawal' : 'Poppins'); ?>", sans-serif;
        --box_shadow : <?php echo e($color_theme->box_shadow ? '0px 10px 15px rgb(236 208 244 / 30%)':'none'); ?>;
        <?php $__currentLoopData = $color_theme->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        --<?php echo e($color->name); ?>: <?php echo e($color->pivot->value); ?>;
                    <?php if(in_array($color->name, ['success', 'danger'])): ?>
        --<?php echo e($color->name); ?>_with_opacity: <?php echo e($color->pivot->value); ?>23;
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
</style><?php /**PATH C:\xampp\htdocs\pcgdb\resources\views/components/root-css.blade.php ENDPATH**/ ?>